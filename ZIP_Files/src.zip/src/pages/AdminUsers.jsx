// src/pages/AdminUsers.jsx
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

import HeaderActions from "../components/HeaderActions";
import ListLoadingSpinner from "../components/ListLoadingSpinner";
import ListEmptyState from "../components/ListEmptyState";
import CardUserAvatar from "../components/CardUserAvatar";
import CardStatBadge from "../components/CardStatBadge";

import { useToast } from "../components/Toast";
import { useAuth } from "../context/AuthContext";
import { useFirebase } from "../context/FirebaseProvider";

import { db } from "../firebase/config";
import {
  collection,
  onSnapshot,
  query,
  orderBy,
  updateDoc,
  doc,
} from "../firebase/firestore";

export default function AdminUsers() {
  const { profile } = useAuth();
  const { push } = useToast();
  const { refreshUser } = useFirebase();

  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [denied, setDenied] = useState(false);

  useEffect(() => {
    // 🚫 No profile yet → do nothing
    if (!profile) return;

    // 🚫 Non-admin users should NOT trigger Firestore listeners
    if (profile.role !== "admin") {
      setDenied(true);
      setLoading(false);
      return;
    }

    // ✅ Admin only — proceed to load users
    const ref = collection(db, "users");
    const q = query(ref, orderBy("createdAt", "desc"));

    const unsub = onSnapshot(
      q,
      (snap) => {
        const items = snap.docs.map((d) => ({
          id: d.id,
          ...d.data(),
        }));

        setUsers(items);
        setLoading(false);
      },
      (err) => {
        console.error("❌ Users listener error:", err);
        push("Failed to load users.", "error");
        setLoading(false);
      }
    );

    return () => unsub();
  }, [profile, push]);

  const handleRoleChange = async (userId, nextRole) => {
    try {
      const ref = doc(db, "users", userId);
      await updateDoc(ref, { role: nextRole });

      push("Role updated", "success");

      if (userId === profile.uid) {
        await refreshUser();
      }
    } catch (err) {
      console.error("❌ Role update failed:", err);
      push("Failed to update role", "error");
    }
  };

  // 🚫 Access denied (coach/athlete)
  if (denied) {
    return (
      <div className="p-6 text-center text-red-600 font-semibold">
        You do not have permission to view this page.
      </div>
    );
  }

  if (loading) {
    return (
      <div className="p-6">
        <ListLoadingSpinner />
      </div>
    );
  }

  return (
    <div className="p-6">
      <HeaderActions title="Users" exportLabel={null} />

      {users.length === 0 ? (
        <ListEmptyState message="No users found." />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
          {users.map((u) => (
            <div
              key={u.id}
              className="bg-white border border-slate-200 rounded-2xl p-4 shadow hover:shadow-yellow-300/40 transition"
            >
              <div className="flex items-center gap-3">
                <CardUserAvatar
                  name={u.displayName || u.name || u.email}
                  imgUrl={u.photoURL || u.imgUrl}
                />

                <div className="min-w-0">
                  <div className="font-semibold text-slate-800">
                    {u.displayName || u.name || "User"}
                  </div>
                  <div className="text-xs text-slate-500 truncate">
                    {u.email}
                  </div>
                </div>
              </div>

              <div className="text-[10px] text-slate-400 mt-1 select-all">
                ID: {u.id}
              </div>

              <div className="mt-3 flex gap-2 flex-wrap">
                <CardStatBadge label="Role" value={u.role} />
                <CardStatBadge label="Team" value={u.teamId || "—"} />
                <CardStatBadge label="Org" value={u.orgId || "—"} />
              </div>

              <div className="mt-4 flex justify-between">
                <Link
                  to={`/coaches/${u.id}`}
                  className="text-xs px-3 py-1.5 rounded-lg border border-yellow-400 text-yellow-600 hover:bg-yellow-400 hover:text-black transition"
                >
                  View Profile →
                </Link>

                <select
                  className="text-xs border rounded-lg px-2 py-1"
                  value={u.role}
                  onChange={(e) => handleRoleChange(u.id, e.target.value)}
                >
                  <option value="admin">Admin</option>
                  <option value="coach">Coach</option>
                  <option value="athlete">Athlete</option>
                </select>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
