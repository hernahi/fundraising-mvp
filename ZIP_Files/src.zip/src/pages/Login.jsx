// src/pages/Login.jsx
import { useState } from "react";
import { auth, googleProvider } from "../firebase/config";
import { signInWithPopup } from "firebase/auth";

export default function Login() {
  const [error, setError] = useState(null);

  const signInWithGoogle = async () => {
    try {
      setError(null);
      await signInWithPopup(auth, googleProvider);
    } catch (e) {
      console.error("Google login error:", e);
      setError(e.message);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <div className="p-6 bg-white rounded shadow text-center">
        <h1 className="text-xl font-bold mb-4">Sign In</h1>

        <button
          onClick={signInWithGoogle}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          Sign in with Google
        </button>

        {error && (
          <p className="text-red-600 text-sm mt-3">{error}</p>
        )}
      </div>
    </div>
  );
}
