import React from "react";
import { Link } from "react-router-dom";

export default function DashboardHome() {
  const metrics = [
    { label: "Active Campaigns", value: 4 },
    { label: "Total Athletes", value: 58 },
    { label: "Total Donors", value: 134 },
    { label: "Funds Raised", value: "$18,420" },
  ];

  const recentActivity = [
    { id: 1, text: "New donor added: Maria Johnson", time: "2h ago" },
    { id: 2, text: "Campaign 'Booster Drive' reached 75% goal", time: "6h ago" },
    { id: 3, text: "Athlete John Doe logged new donations", time: "1d ago" },
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-slate-800 border-b-2 border-yellow-400 pb-1">
          Dashboard Overview
        </h1>
        <span className="text-xs text-slate-400 animate-fadeIn">
          Last synced: {new Date().toLocaleTimeString()}
        </span>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {metrics.map((m) => (
          <div
            key={m.label}
            className="bg-white border border-slate-200 rounded-xl shadow p-4 hover:shadow-[0_0_10px_rgba(250,204,21,0.25)] transition-all duration-300"
          >
            <p className="text-slate-500 text-sm">{m.label}</p>
            <p className="text-2xl font-semibold text-slate-800 mt-1">
              {m.value}
            </p>
          </div>
        ))}
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-xl shadow p-4 border border-slate-200">
        <div className="flex items-center justify-between border-b border-slate-200 pb-2 mb-3">
          <h2 className="font-semibold text-slate-700">Recent Activity</h2>
          <Link
            to="/activity"
            className="text-yellow-500 text-sm hover:underline font-medium"
          >
            View All →
          </Link>
        </div>

        <ul className="divide-y divide-slate-100">
          {recentActivity.map((a) => (
            <li
              key={a.id}
              className="py-2 flex justify-between text-sm text-slate-600 hover:text-yellow-500 transition"
            >
              <span>{a.text}</span>
              <span className="text-xs text-slate-400">{a.time}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
