// src/pages/Messages.jsx
import { useEffect, useState } from "react";

import { useAuth } from "../context/AuthContext";
import ListLoadingSpinner from "../components/ListLoadingSpinner";
import ListEmptyState from "../components/ListEmptyState";
import AvatarCircle from "../components/AvatarCircle";
import HeaderActions from "../components/HeaderActions";

import { db } from "../firebase/config";
import {
  collection,
  query,
  where,
  orderBy,
  onSnapshot,
} from "../firebase/firestore";

export default function Messages() {
  const { profile, loading: authLoading } = useAuth();
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState("");

  useEffect(() => {
    if (authLoading || !profile) return;

    const ref = collection(db, "messages");
    const qRef = query(
      ref,
      where("orgId", "==", profile.orgId),
      orderBy("createdAt", "desc")
    );

    const unsub = onSnapshot(
      qRef,
      (snap) => {
        const rows = snap.docs.map((d) => ({
          id: d.id,
          ...d.data(),
        }));
        setMessages(rows);
        setLoading(false);
        setLastUpdated(new Date().toLocaleTimeString());
      },
      (err) => {
        console.error("❌ Messages listener error:", err);
        setLoading(false);
      }
    );

    return () => unsub();
  }, [authLoading, profile]);

  if (authLoading) {
    return (
      <div className="p-6">
        <ListLoadingSpinner />
      </div>
    );
  }

  return (
    <div className="p-6">
      <HeaderActions
        title="Messages"
        addLabel={null}
        exportLabel={null}
        onExport={null}
        lastUpdated={lastUpdated}
      />

      {loading ? (
        <ListLoadingSpinner />
      ) : messages.length === 0 ? (
        <ListEmptyState message="No outreach messages have been logged yet." />
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm">
          <ul className="divide-y">
            {messages.map((m) => (
              <li
                key={m.id}
                className="px-4 py-4 flex gap-3 hover:bg-slate-50 transition"
              >
                {/* ⭐ Avatar Inheritance Hardening */}
                <div className="mt-1">
                  <AvatarCircle
                    name={m.toName || m.to || "Recipient"}
                    imgUrl={
                      m.toImgUrl ||    // manually stored
                      m.toPhotoURL ||  // normalized
                      null
                    }
                    size="sm"
                  />
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <p className="text-sm font-semibold text-slate-800 truncate">
                      {m.subject || "Message"}
                    </p>
                    <span className="text-[11px] text-slate-400 shrink-0">
                      {m.createdAt?.toDate
                        ? m.createdAt.toDate().toLocaleString()
                        : "—"}
                    </span>
                  </div>

                  <p className="text-xs text-slate-500 mb-1">
                    {m.channel === "sms"
                      ? "SMS"
                      : m.channel === "email"
                      ? "Email"
                      : "Outreach"}
                  </p>

                  <p className="text-sm text-slate-700 line-clamp-2">
                    {m.body || "No preview available."}
                  </p>
                </div>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
