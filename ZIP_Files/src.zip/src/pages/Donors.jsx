import React, { useEffect, useState } from "react";
import { collection, query, where, onSnapshot } from "firebase/firestore";
import { db } from "../firebase/config";

export default function Donors() {
  const [donors, setDonors] = useState([]);
  const [loading, setLoading] = useState(true);

  // Load profile from localStorage
  const rawProfile = localStorage.getItem("fundraising-profile");
  const profile = rawProfile ? JSON.parse(rawProfile) : null;

  const orgId = profile?.orgId || null;

  useEffect(() => {
    if (!orgId) {
      console.warn("Donors.jsx — No orgId; skipping donor load.");
      setDonors([]);
      setLoading(false);
      return;
    }

    const qRef = query(collection(db, "donors"), where("orgId", "==", orgId));

    const unsub = onSnapshot(
      qRef,
      (snap) => {
        const list = snap.docs.map((docSnap) => {
          const data = docSnap.data();

          // Normalize image URL — reject empty strings so AvatarCircle stops warning
          let imgUrl = null;
          if (data.imgUrl && typeof data.imgUrl === "string" && data.imgUrl.trim() !== "") {
            imgUrl = data.imgUrl.trim();
          } else if (data.photoURL && typeof data.photoURL === "string" && data.photoURL.trim() !== "") {
            imgUrl = data.photoURL.trim();
          }

          return {
            id: docSnap.id,
            name: data.name || "Anonymous",
            email: data.email || "",
            amount: data.amount || 0,
            imgUrl, // clean and normalized
          };
        });

        setDonors(list);
        setLoading(false);
      },
      (err) => {
        console.error("❌ Donors listener error:", err.message);
        setLoading(false);
      }
    );

    return () => unsub();
  }, [orgId]);

  if (loading) return <p>Loading donors...</p>;

  return (
    <div className="p-4">
      {donors.length === 0 && <p>No donors yet.</p>}
      {donors.map((d) => (
        <div key={d.id} className="border rounded p-3 mb-3">
          <strong>{d.name}</strong>
          <p>{d.email || "No email provided"}</p>
          <p>${d.amount}</p>
        </div>
      ))}
    </div>
  );
}
