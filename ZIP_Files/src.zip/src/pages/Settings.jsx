// src/pages/Settings.jsx
import { useAuth } from "../context/AuthContext";
import AvatarCircle from "../components/AvatarCircle";

export default function Settings() {
  const { profile } = useAuth();

  const name =
    profile?.displayName || profile?.name || profile?.email || "User";
  const email = profile?.email || "—";
  const role = profile?.role || "—";
  const orgId = profile?.orgId || "—";
  const teamId = profile?.teamId || "—";

  return (
    <div className="p-6">
      <div className="max-w-3xl mx-auto space-y-6">
        {/* HEADER */}
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-semibold text-slate-900">
            Settings
          </h1>
          <span className="text-xs px-3 py-1 rounded-full bg-slate-100 text-slate-700 border border-slate-200">
            Account &amp; Workspace
          </span>
        </div>

        {/* PROFILE CARD */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 flex items-center gap-4">
          <AvatarCircle
            name={name}
            imgUrl={profile?.photoURL || profile?.imgUrl}
            size="lg"
          />
          <div className="min-w-0">
            <p className="text-base font-semibold text-slate-900 truncate">
              {name}
            </p>
            <p className="text-sm text-slate-600 truncate">{email}</p>
            <p className="text-xs text-slate-400 mt-1">
              Signed in as <span className="font-medium">{role}</span>
            </p>
          </div>
        </div>

        {/* ORG / TEAM INFO */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
          <h2 className="text-sm font-semibold text-slate-800 mb-3">
            Workspace
          </h2>
          <dl className="space-y-2 text-sm">
            <DetailRow label="Organization ID" value={orgId} />
            <DetailRow label="Team ID" value={teamId} />
            <DetailRow
              label="Role"
              value={role === "admin" ? "Administrator" : role}
            />
          </dl>
          <p className="mt-4 text-xs text-slate-500">
            Workspace settings (org name, branding, etc.) will be configurable
            from this screen in a future phase.
          </p>
        </div>

        {/* PLACEHOLDER FOR FUTURE TOGGLES */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
          <h2 className="text-sm font-semibold text-slate-800 mb-3">
            Notifications &amp; Preferences
          </h2>
          <p className="text-sm text-slate-600">
            Email and SMS notification preferences, campaign defaults, and
            other personal settings will appear here in a later release.
          </p>
        </div>
      </div>
    </div>
  );
}

function DetailRow({ label, value }) {
  return (
    <div className="flex justify-between gap-3">
      <dt className="text-slate-500">{label}</dt>
      <dd className="text-slate-800 text-right">{value || "—"}</dd>
    </div>
  );
}
