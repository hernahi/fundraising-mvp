// src/pages/PublicCampaign.jsx (PRODUCTION + DONATE BUTTON ADDED)

import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

import { db } from "../firebase/config";
import {
  doc,
  getDoc,
  collection,
  query,
  where,
  getDocs,
} from "../firebase/firestore";

import AvatarCircle from "../components/AvatarCircle";
import ListLoadingSpinner from "../components/ListLoadingSpinner";
import CardStatBadge from "../components/CardStatBadge";

export default function PublicCampaign() {
  const { campaignId } = useParams();

  const [campaign, setCampaign] = useState(null);
  const [athletes, setAthletes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  /* ===========================================================
     SECURITY: Strict URL sanitizer (CSP-safe)
     =========================================================== */
  const safeImg = (url) => {
    if (!url) return null;
    try {
      const u = new URL(url);
      if (["http:", "https:"].includes(u.protocol)) return u.href;
      return null;
    } catch {
      return null;
    }
  };

  /* ===========================================================
     LOAD CAMPAIGN — PUBLIC FIELDS ONLY
     =========================================================== */
  useEffect(() => {
    if (!campaignId) return;

    const load = async () => {
      setLoading(true);

      const ref = doc(db, "campaigns", campaignId);
      const snap = await getDoc(ref);

      if (!snap.exists()) {
        setNotFound(true);
        setLoading(false);
        return;
      }

      const data = snap.data() || {};

      if (!data.isPublic) {
        setNotFound(true);
        setLoading(false);
        return;
      }

      const clean = {
        id: snap.id,
        name: typeof data.name === "string" ? data.name.slice(0, 200) : "Campaign",
        orgId: typeof data.orgId === "string" ? data.orgId : null,
        teamId: typeof data.teamId === "string" ? data.teamId : null,
        description:
          typeof data.description === "string"
            ? data.description.slice(0, 5000)
            : "",
        imgUrl: safeImg(data.imgUrl),
        goal: Number(data.goal) || 0,
        raised: Number(data.raised) || 0,
      };

      setCampaign(clean);
      setLoading(false);
    };

    load().catch((err) => {
      console.error("❌ PublicCampaign load error:", err);
      setNotFound(true);
      setLoading(false);
    });
  }, [campaignId]);

  /* ===========================================================
     LOAD ATHLETES — PUBLIC FIELDS ONLY
     =========================================================== */
  useEffect(() => {
    if (!campaign?.orgId || !campaign?.teamId) return;

    const loadAthletes = async () => {
      const ref = collection(db, "athletes");

      const q = query(
        ref,
        where("orgId", "==", campaign.orgId),
        where("teamId", "==", campaign.teamId),
        where("isPublic", "==", true)
      );

      const snap = await getDocs(q);

      const list = snap.docs.map((d) => {
        const a = d.data() || {};
        return {
          id: d.id,
          name: typeof a.name === "string" ? a.name.slice(0, 150) : "Athlete",
          imgUrl: safeImg(a.imgUrl),
          publicLinkId:
            typeof a.publicLinkId === "string" ? a.publicLinkId : null,
        };
      });

      setAthletes(list);
    };

    loadAthletes().catch((err) => {
      console.error("❌ PublicCampaign athlete load error:", err);
    });
  }, [campaign]);

  /* ===========================================================
     UI
     =========================================================== */
  if (loading)
    return (
      <div className="p-6">
        <ListLoadingSpinner />
      </div>
    );

  if (notFound || !campaign)
    return (
      <div className="p-6 max-w-2xl mx-auto">
        <div className="bg-red-50 border border-red-200 text-red-700 rounded-2xl p-4 text-center">
          This public campaign link is not available.
        </div>
      </div>
    );

  /* ===========================================================
     DONATE BUTTON (NEW)
     =========================================================== */
  const donateHref = `/donate/campaign/${encodeURIComponent(campaign.id)}`;

  return (
    <div className="p-6">
      <div className="max-w-4xl mx-auto space-y-6">

        {/* =============================
            CAMPAIGN HEADER
        ============================== */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
          <div className="flex flex-col sm:flex-row gap-6">
            <div className="shrink-0">
              <AvatarCircle
                name={campaign.name}
                imgUrl={campaign.imgUrl}
                size="xl"
              />
            </div>

            <div className="flex-1 min-w-0">
              <h1 className="text-2xl font-bold text-slate-900 truncate">
                {campaign.name}
              </h1>

              <p className="text-sm text-slate-600 mt-2 whitespace-pre-line">
                {campaign.description}
              </p>

              <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-4">
                <CardStatBadge label="Goal" value={`$${campaign.goal}`} />
                <CardStatBadge label="Raised" value={`$${campaign.raised}`} />
                <CardStatBadge label="Team" value={campaign.teamId || "—"} />
              </div>

              {/* ⭐ DONATE BUTTON */}
              <div className="mt-6">
                <a
                  href={donateHref}
                  className="inline-block w-full sm:w-auto text-center px-6 py-3 rounded-xl bg-yellow-500 hover:bg-yellow-600 text-slate-900 font-semibold shadow-md transition"
                >
                  Donate to This Campaign →
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* =============================
            ATHLETES
        ============================== */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
          <h2 className="text-lg font-semibold text-slate-900 mb-4">
            Support an Athlete
          </h2>

          {athletes.length === 0 ? (
            <p className="text-slate-500 text-sm">No public athletes available.</p>
          ) : (
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {athletes.map((a) => (
                <li
                  key={a.id}
                  className="bg-slate-50 rounded-xl border border-slate-200 p-4 flex items-center gap-4"
                >
                  <AvatarCircle name={a.name} imgUrl={a.imgUrl} size="lg" />

                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-slate-800">{a.name}</p>

                    {a.publicLinkId && (
                      <a
                        href={`/a/${encodeURIComponent(a.publicLinkId)}`}
                        className="text-xs text-yellow-600 underline hover:text-yellow-500"
                      >
                        View Athlete →
                      </a>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

      </div>
    </div>
  );
}
