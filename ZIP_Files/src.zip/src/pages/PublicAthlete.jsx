// src/pages/PublicAthlete.jsx
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

import { db } from "../firebase/config";
import { doc, getDoc } from "../firebase/firestore";

import AvatarCircle from "../components/AvatarCircle";
import ListLoadingSpinner from "../components/ListLoadingSpinner";
import CardStatBadge from "../components/CardStatBadge";

export default function PublicAthlete() {
  const { athleteId } = useParams();

  const [athlete, setAthlete] = useState(null);
  const [campaign, setCampaign] = useState(null);
  const [notFound, setNotFound] = useState(false);
  const [loading, setLoading] = useState(true);

  // ----------------------------------------------------
  // STRICT CSP-SAFE IMG SANITIZER
  // ----------------------------------------------------
  const safeImg = (url) => {
    if (!url || typeof url !== "string") return null;
    try {
      const parsed = new URL(url);
      // Allow ONLY https / storage.googleapis
      if (!["https:"].includes(parsed.protocol)) return null;
      return parsed.href;
    } catch {
      return null;
    }
  };

  // ----------------------------------------------------
  // Load athlete — PRODUCTION GRADE VALIDATION
  // ----------------------------------------------------
  useEffect(() => {
    if (!athleteId) return;

    const loadAthlete = async () => {
      setLoading(true);
      try {
        const ref = doc(db, "athletes", athleteId);
        const snap = await getDoc(ref);

        if (!snap.exists()) {
          setNotFound(true);
          setLoading(false);
          return;
        }

        const raw = snap.data();

        if (!raw.isPublic) {
          setNotFound(true);
          setLoading(false);
          return;
        }

        const clean = {
          id: snap.id,
          name: typeof raw.name === "string" ? raw.name.slice(0, 80) : "Athlete",
          imgUrl: safeImg(raw.imgUrl),
          story:
            typeof raw.story === "string" ? raw.story.slice(0, 2000) : "",
          donations: Number(raw.donations) || 0,
          publicCampaignId:
            typeof raw.publicCampaignId === "string"
              ? raw.publicCampaignId
              : null,
        };

        setAthlete(clean);
      } catch (e) {
        console.error("❌ PublicAthlete load error:", e);
        setNotFound(true);
      }

      setLoading(false);
    };

    loadAthlete();
  }, [athleteId]);

  // ----------------------------------------------------
  // Load linked campaign (public only)
  // ----------------------------------------------------
  useEffect(() => {
    if (!athlete || !athlete.publicCampaignId) return;

    const loadCampaign = async () => {
      try {
        const ref = doc(db, "campaigns", athlete.publicCampaignId);
        const snap = await getDoc(ref);

        if (!snap.exists()) return;

        const raw = snap.data();

        if (!raw.isPublic) return;

        setCampaign({
          id: snap.id,
          name: raw.name || "Campaign",
          imgUrl: safeImg(raw.imgUrl),
          goal: Number(raw.goal) || 0,
          raised: Number(raw.raised) || 0,
        });
      } catch (e) {
        console.error("❌ PublicAthlete campaign load error:", e);
      }
    };

    loadCampaign();
  }, [athlete]);

  // ----------------------------------------------------
  // RENDERING
  // ----------------------------------------------------
  if (loading) {
    return (
      <div className="p-6">
        <ListLoadingSpinner />
      </div>
    );
  }

  if (notFound || !athlete) {
    return (
      <div className="p-6 max-w-2xl mx-auto">
        <div className="bg-red-50 border border-red-200 text-red-700 rounded-2xl p-4 text-center">
          This athlete link is not available.
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="max-w-4xl mx-auto space-y-6">

        {/* HEADER */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm flex flex-col sm:flex-row gap-6">
          <div className="shrink-0">
            <AvatarCircle
              name={athlete.name}
              imgUrl={athlete.imgUrl}
              size="xl"
            />
          </div>

          <div className="flex-1 min-w-0">
            <h1 className="text-2xl font-bold text-slate-900 truncate">
              {athlete.name}
            </h1>

            <p className="text-sm text-slate-600 whitespace-pre-line mt-2">
              {athlete.story}
            </p>

            <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-4">
              <CardStatBadge label="Donations" value={athlete.donations} />
              <CardStatBadge
                label="Campaign"
                value={campaign ? campaign.name : "—"}
              />
            </div>
          </div>
        </div>

        {/* CAMPAIGN SECTION */}
        {campaign && (
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
            <h2 className="text-lg font-semibold text-slate-900 mb-2">
              Part of Campaign
            </h2>

            <div className="flex items-center gap-4">
              <AvatarCircle
                name={campaign.name}
                imgUrl={campaign.imgUrl}
                size="lg"
              />

              <div className="min-w-0 flex-1">
                <p className="font-semibold text-slate-800">
                  {campaign.name}
                </p>

                <div className="mt-2 grid grid-cols-2 gap-4 max-w-xs">
                  <CardStatBadge
                    label="Goal"
                    value={`$${campaign.goal}`}
                  />
                  <CardStatBadge
                    label="Raised"
                    value={`$${campaign.raised}`}
                  />
                </div>

                {/* VIEW CAMPAIGN */}
                <a
                  href={`/c/${campaign.id}`}
                  className="mt-3 inline-block text-sm text-yellow-600 underline hover:text-yellow-500"
                >
                  View Campaign →
                </a>

                {/* -------------------------------------------------- */}
                {/* DONATE BUTTON — PRODUCTION GRADE + LOCKED ROUTE    */}
                {/* -------------------------------------------------- */}
                <a
                  href={`/donate/${campaign.id}`}
                  className="mt-4 inline-block px-5 py-2 rounded-xl bg-yellow-500 hover:bg-yellow-600 text-white font-semibold text-sm shadow transition"
                >
                  Donate to {athlete.name}
                </a>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
