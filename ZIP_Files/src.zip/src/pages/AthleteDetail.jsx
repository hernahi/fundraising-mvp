// src/pages/AthleteDetail.jsx
import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";

import { useAuth } from "../context/AuthContext";
import { currency } from "../utils/currency";

// NEW: unified avatar system
import AvatarCircle from "../components/AvatarCircle";
import ListLoadingSpinner from "../components/ListLoadingSpinner";
import CardStatBadge from "../components/CardStatBadge";

// Firestore
import { db } from "../firebase/config";
import { doc, onSnapshot } from "firebase/firestore";

export default function AthleteDetail() {
  const { id } = useParams();
  const { profile, loading: authLoading } = useAuth();

  const [athlete, setAthlete] = useState(null);
  const [loading, setLoading] = useState(true);
  const [noAccess, setNoAccess] = useState(false);

  /* ---------------------------------------------------------
     LOAD ATHLETE
  --------------------------------------------------------- */
  useEffect(() => {
    if (authLoading || !profile || !id) return;

    const ref = doc(db, "athletes", id);

    const unsub = onSnapshot(
      ref,
      (snap) => {
        if (!snap.exists()) {
          setAthlete(null);
          setNoAccess(false);
          setLoading(false);
          return;
        }

        const data = { id: snap.id, ...snap.data() };

        // org-scoped RBAC
        if (data.orgId && data.orgId !== profile.orgId) {
          console.warn("❌ Athlete belongs to a different org");
          setNoAccess(true);
          setAthlete(null);
        } else {
          setNoAccess(false);
          setAthlete(data);
        }

        setLoading(false);
      },
      (err) => {
        console.error("❌ Athlete listener error:", err);
        setLoading(false);
      }
    );

    return () => unsub();
  }, [id, profile, authLoading]);

  /* ---------------------------------------------------------
     STATES
  --------------------------------------------------------- */
  if (authLoading || loading) {
    return (
      <div className="p-6">
        <ListLoadingSpinner />
      </div>
    );
  }

  if (noAccess) {
    return (
      <div className="p-6 max-w-2xl mx-auto">
        <div className="bg-red-50 border border-red-200 text-red-700 rounded-2xl p-4">
          You don&apos;t have access to view this athlete.
        </div>
      </div>
    );
  }

  if (!athlete) {
    return (
      <div className="p-6 max-w-2xl mx-auto">
        <div className="bg-yellow-50 border border-yellow-200 text-yellow-800 rounded-2xl p-4">
          Athlete not found.
        </div>
      </div>
    );
  }

  /* ---------------------------------------------------------
     EXTRACT FIELDS
  --------------------------------------------------------- */
  const { name, team, teamId, imgUrl, donations, createdAt, userId, role } =
    athlete;

  const createdDate =
    createdAt && createdAt.toDate
      ? createdAt.toDate().toLocaleDateString()
      : "—";

  /* ---------------------------------------------------------
     UI
  --------------------------------------------------------- */
  return (
    <div className="p-6">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* ======================================================
           HERO HEADER
        ====================================================== */}
        <div className="bg-gradient-to-r from-yellow-50 to-slate-50 border border-slate-200 rounded-2xl shadow-sm p-6 sm:p-7 flex flex-col sm:flex-row sm:items-center gap-5">
          <div className="shrink-0">
            <AvatarCircle name={name} imgUrl={imgUrl} size="xl" />
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <h1 className="text-2xl font-semibold text-slate-900 truncate">
                  {name || "Unnamed Athlete"}
                </h1>
                <p className="text-sm text-slate-600 truncate">
                  {team || "Unassigned Team"}{" "}
                  {teamId && (
                    <span className="text-slate-400">· {teamId}</span>
                  )}
                </p>
                <p className="mt-1 text-xs text-slate-400">
                  Athlete profile · Created {createdDate}
                </p>
              </div>

              <div className="flex flex-col items-end gap-2">
                <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-50 text-emerald-700 border border-emerald-100">
                  {role === "coach" || role === "admin"
                    ? role.charAt(0).toUpperCase() + role.slice(1)
                    : "Athlete"}
                </span>

                {userId && (
                  <p className="text-[11px] text-slate-400 select-all">
                    User ID: {userId}
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* ======================================================
           MAIN CONTENT GRID
        ====================================================== */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* LEFT: Stats + Activity */}
          <div className="lg:col-span-2 space-y-6">
            {/* STATS */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
              <h2 className="text-sm font-semibold text-slate-800 mb-4">
                Performance Summary
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <CardStatBadge
                  label="Total Donations (Count)"
                  value={donations ?? 0}
                />
                <CardStatBadge label="Estimated Raised" value={currency(0)} />
                <CardStatBadge label="Team" value={team || "Unassigned"} />
              </div>
            </div>

            {/* ACTIVITY */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
              <h2 className="text-sm font-semibold text-slate-800 mb-2">
                Activity
              </h2>
              <p className="text-sm text-slate-500">
                Athlete donation history, campaign participation, and activity
                logs will be available in a future update.
              </p>
            </div>
          </div>

          {/* RIGHT COLUMN: Meta Details */}
          <div className="space-y-4">
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
              <h3 className="text-sm font-semibold text-slate-800 mb-3">
                Profile Details
              </h3>

              <dl className="space-y-2 text-sm">
                <DetailRow label="Name" value={name} />
                <DetailRow label="Team" value={team} />
                <DetailRow label="Team ID" value={teamId} />
                <DetailRow label="Org" value={athlete.orgId} />
                <DetailRow label="Created" value={createdDate} />
              </dl>

              <div className="mt-4 flex justify-between">
                <Link
                  to="/athletes"
                  className="text-xs px-3 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 transition"
                >
                  ← Back to Athletes
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------
   Small component for right-hand details
--------------------------------------------------------- */
function DetailRow({ label, value }) {
  return (
    <div className="flex justify-between gap-3">
      <dt className="text-slate-500">{label}</dt>
      <dd className="text-slate-800 text-right">{value || "—"}</dd>
    </div>
  );
}
