// src/pages/TeamDetail.jsx
import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";

import { useAuth } from "../context/AuthContext";
import ListLoadingSpinner from "../components/ListLoadingSpinner";
import CardStatBadge from "../components/CardStatBadge";
import AvatarCircle from "../components/AvatarCircle";

import { db } from "../firebase/config";
import {
  doc,
  onSnapshot,
  collection,
  query,
  where,
  getDocs,
} from "../firebase/firestore";

export default function TeamDetail() {
  const { id } = useParams();
  const { profile, loading: authLoading } = useAuth();

  const [team, setTeam] = useState(null);
  const [noAccess, setNoAccess] = useState(false);
  const [loading, setLoading] = useState(true);

  const [campaigns, setCampaigns] = useState([]);
  const [athletes, setAthletes] = useState([]);
  const [coaches, setCoaches] = useState([]);

  /* -------------------------------------------------------------
     Load team
  ------------------------------------------------------------- */
  useEffect(() => {
    if (authLoading || !profile || !id) return;

    const ref = doc(db, "teams", id);

    const unsub = onSnapshot(
      ref,
      snap => {
        if (!snap.exists()) {
          setTeam(null);
          setNoAccess(false);
          setLoading(false);
          return;
        }

        const data = { id: snap.id, ...snap.data() };

        if (data.orgId && data.orgId !== profile.orgId) {
          console.warn("❌ Team belongs to a different org");
          setNoAccess(true);
          setTeam(null);
        } else {
          setNoAccess(false);
          setTeam(data);
        }

        setLoading(false);
      },
      err => {
        console.error("❌ Team listener error:", err);
        setLoading(false);
      }
    );

    return () => unsub();
  }, [id, profile, authLoading]);

  /* -------------------------------------------------------------
     Load sub-collections
  ------------------------------------------------------------- */
  useEffect(() => {
    if (!team || !team.id) return;

    const load = async () => {
      try {
        const camQ = query(
          collection(db, "campaigns"),
          where("teamId", "==", team.id),
          where("orgId", "==", team.orgId)
        );
        const camSnap = await getDocs(camQ);
        setCampaigns(camSnap.docs.map(d => ({ id: d.id, ...d.data() })));

        const athQ = query(
          collection(db, "athletes"),
          where("teamId", "==", team.id),
          where("orgId", "==", team.orgId)
        );
        const athSnap = await getDocs(athQ);
        setAthletes(athSnap.docs.map(d => ({ id: d.id, ...d.data() })));

        const coachQ = query(
          collection(db, "coaches"),
          where("teamId", "==", team.id),
          where("orgId", "==", team.orgId)
        );
        const coachSnap = await getDocs(coachQ);
        setCoaches(coachSnap.docs.map(d => ({ id: d.id, ...d.data() })));
      } catch (err) {
        console.error("❌ Error loading team relations:", err);
      }
    };

    load();
  }, [team]);

  /* -------------------------------------------------------------
     States
  ------------------------------------------------------------- */
  if (authLoading || loading) {
    return (
      <div className="p-6">
        <ListLoadingSpinner />
      </div>
    );
  }

  if (noAccess) {
    return (
      <div className="p-6 max-w-2xl mx-auto">
        <div className="bg-red-50 border border-red-200 text-red-700 rounded-2xl p-4">
          You don’t have access to view this team.
        </div>
      </div>
    );
  }

  if (!team) {
    return (
      <div className="p-6 max-w-2xl mx-auto">
        <div className="bg-yellow-50 border border-yellow-200 text-yellow-800 rounded-2xl p-4">
          Team not found.
        </div>
      </div>
    );
  }

  const { name, sport, level, orgId, createdAt } = team;

  const createdDate =
    createdAt?.toDate ? createdAt.toDate().toLocaleDateString() : "—";

  // ⭐ Phase D — Avatar inheritance fallback
  const avatarUrl =
    team.logoUrl ||
    team.imgUrl ||
    null; // AvatarCircle handles final null fallback

  /* -------------------------------------------------------------
     UI
  ------------------------------------------------------------- */
  return (
    <div className="p-6">
      <div className="max-w-5xl mx-auto space-y-6">

        {/* HEADER */}
        <div className="bg-gradient-to-r from-yellow-50 to-slate-50 border border-slate-200 rounded-2xl shadow-sm p-6 sm:p-7 flex flex-col sm:flex-row sm:items-center gap-5">
          <AvatarCircle name={name || "Team"} imgUrl={avatarUrl} size="xl" />

          <div className="flex-1 min-w-0">
            <h1 className="text-2xl font-semibold text-slate-900 truncate">
              {name}
            </h1>
            <p className="text-sm text-slate-600 truncate">
              {sport || "Sport N/A"}{" "}
              {level && <span className="text-slate-400">· {level}</span>}
            </p>
            <p className="mt-1 text-xs text-slate-400">
              Team profile · Created {createdDate}
            </p>
          </div>

          <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-indigo-50 text-indigo-700 border border-indigo-200">
            Team
          </span>
        </div>

        {/* GRID */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

          {/* LEFT */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
              <h2 className="text-sm font-semibold text-slate-800 mb-4">
                Team Summary
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <CardStatBadge label="Campaigns" value={campaigns.length} />
                <CardStatBadge label="Athletes" value={athletes.length} />
                <CardStatBadge label="Coaches" value={coaches.length} />
              </div>
            </div>

            {/* CAMPAIGNS LIST */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
              <h2 className="text-sm font-semibold text-slate-800 mb-4">
                Campaigns
              </h2>

              {campaigns.length === 0 ? (
                <p className="text-sm text-slate-500">
                  No campaigns for this team yet.
                </p>
              ) : (
                <ul className="divide-y">
                  {campaigns.map(c => (
                    <li key={c.id} className="py-3 flex items-center justify-between">
                      <div className="min-w-0">
                        <p className="font-medium text-slate-800">{c.name}</p>
                        <p className="text-xs text-slate-500 truncate">
                          Goal: {c.goal}
                        </p>
                      </div>
                      <Link
                        to={`/campaigns/${c.id}`}
                        className="text-xs text-yellow-600 underline hover:text-yellow-500"
                      >
                        View →
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            {/* ATHLETES LIST */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
              <h2 className="text-sm font-semibold text-slate-800 mb-4">
                Athletes
              </h2>

              {athletes.length === 0 ? (
                <p className="text-sm text-slate-500">No athletes assigned yet.</p>
              ) : (
                <ul className="divide-y">
                  {athletes.map(a => {
                    // ⭐ Phase D — Athlete avatar fallback
                    const aAvatar =
                      a.imgUrl ||
                      a.photoURL ||
                      null;

                    return (
                      <li key={a.id} className="py-3 flex items-center justify-between">
                        <div className="min-w-0">
                          <p className="font-medium text-slate-800">{a.name}</p>
                          <p className="text-xs text-slate-500 truncate">
                            {a.team}
                          </p>
                        </div>
                        <Link
                          to={`/athletes/${a.id}`}
                          className="text-xs text-yellow-600 underline hover:text-yellow-500"
                        >
                          View →
                        </Link>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          </div>

          {/* RIGHT */}
          <div className="space-y-4">
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
              <h3 className="text-sm font-semibold text-slate-800 mb-3">
                Team Details
              </h3>

              <dl className="space-y-2 text-sm">
                <DetailRow label="Name" value={name} />
                <DetailRow label="Sport" value={sport} />
                <DetailRow label="Level" value={level} />
                <DetailRow label="Org" value={orgId} />
                <DetailRow label="Created" value={createdDate} />
              </dl>

              <div className="mt-4">
                <Link
                  to="/teams"
                  className="text-xs px-3 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 transition"
                >
                  ← Back to Teams
                </Link>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}

function DetailRow({ label, value }) {
  return (
    <div className="flex justify-between gap-3">
      <dt className="text-slate-500">{label}</dt>
      <dd className="text-slate-800 text-right">{value || "—"}</dd>
    </div>
  );
}
