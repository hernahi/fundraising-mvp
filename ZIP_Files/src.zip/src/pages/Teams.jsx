// src/pages/Teams.jsx
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

import HeaderActions from "../components/HeaderActions";
import ListLoadingSpinner from "../components/ListLoadingSpinner";
import ListEmptyState from "../components/ListEmptyState";
import CardStatBadge from "../components/CardStatBadge";
import CardUserAvatarSmall from "../components/CardUserAvatarSmall";

import { useToast } from "../components/Toast";
import { useAuth } from "../context/AuthContext";

import { db } from "../firebase/config";
import {
  collection,
  onSnapshot,
  query,
  where,
  orderBy,
} from "../firebase/firestore";

// -------------------------------
// STEP 4C: TEAM AVATAR HARDENING
// -------------------------------

/**
 * Ensures every team card renders safe, validated avatar fields
 */
const normalizeTeam = (teamDoc) => {
  return {
    ...teamDoc,

    // Defensive fallbacks
    name: teamDoc.name || "Unnamed Team",
    sport: teamDoc.sport || "—",
    season: teamDoc.season || "Season N/A",
    location: teamDoc.location || "",

    // Avatar creator fallback pipeline
    createdByName: teamDoc.createdByName || "Admin",

    // Normalize image URLs so AvatarCircle never receives "" or undefined
    createdByImg:
      typeof teamDoc.createdByImg === "string" &&
      teamDoc.createdByImg.trim().length > 0
        ? teamDoc.createdByImg
        : null,
  };
};
// -------------------------------

export default function Teams() {
  const { push } = useToast();
  const { profile, loading: authLoading } = useAuth();

  const [teams, setTeams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState("");

  useEffect(() => {
    if (authLoading || !profile) return;

    const ref = collection(db, "teams");
    const q = query(
      ref,
      where("orgId", "==", profile.orgId),
      orderBy("name", "asc")
    );

    const unsub = onSnapshot(
      q,
      (snapshot) => {
        const data = snapshot.docs.map((d) => normalizeTeam({ id: d.id, ...d.data() }));
        setTeams(data);
        setLoading(false);
        setLastUpdated(new Date().toLocaleTimeString());
      },
      (err) => {
        console.error("⚠️ Firestore listener error (teams):", err);
        push("Failed to sync teams", "error");
        setLoading(false);
      }
    );

    return () => unsub();
  }, [authLoading, profile, push]);

  if (authLoading || !profile) {
    return (
      <div className="p-6">
        <ListLoadingSpinner />
      </div>
    );
  }

  const handleExport = () => {
    push("Team export will be available in a later update", "info");
  };

  return (
    <div className="p-6">
      <HeaderActions
        title="Teams"
        addLabel={<Link to="/teams/new">+ Add Team</Link>}
        exportLabel="Export CSV"
        onExport={handleExport}
        lastUpdated={lastUpdated}
      />

      {loading ? (
        <ListLoadingSpinner />
      ) : teams.length === 0 ? (
        <ListEmptyState message="No teams found. Add one to get started." />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
          {teams.map((t) => (
            <div
              key={t.id}
              className="bg-white rounded-2xl border border-slate-200 p-4 shadow hover:shadow-yellow-300/40 transition-all duration-300"
            >
              <div className="flex items-start justify-between gap-3">
                {/* Team text */}
                <div className="min-w-0">
                  <div className="font-semibold text-slate-800">{t.name}</div>
                  <div className="text-xs text-slate-500">
                    {t.sport} • {t.season}
                  </div>
                  <div className="text-xs text-slate-500">{t.location}</div>
                </div>

                {/* Team creator avatar — now fully hardened */}
                <CardUserAvatarSmall
                  name={t.createdByName}
                  imgUrl={t.createdByImg}
                />
              </div>

              <div className="text-[10px] text-slate-400 mt-1 select-all">
                ID: {t.id}
              </div>

              <div className="mt-3 flex gap-2 flex-wrap">
                <CardStatBadge label="Sport" value={t.sport} />
                <CardStatBadge label="Season" value={t.season} />
                <CardStatBadge label="Location" value={t.location || "—"} />
              </div>

              <div className="mt-4 flex justify-end gap-2">
                <Link
                  to={`/teams/${t.id}`}
                  className="text-sm px-3 py-1.5 rounded-lg border border-yellow-400 text-yellow-600 hover:bg-yellow-400 hover:text-slate-900 transition"
                >
                  View →
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
