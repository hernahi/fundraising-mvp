// src/pages/DonorDetail.jsx
import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";

import { useAuth } from "../context/AuthContext";
import AvatarCircle from "../components/AvatarCircle";
import ListLoadingSpinner from "../components/ListLoadingSpinner";
import CardStatBadge from "../components/CardStatBadge";
import { currency } from "../utils/currency";

// Firestore
import { db } from "../firebase/config";
import { doc, collection, query, where, onSnapshot } from "firebase/firestore";

export default function DonorDetail() {
  const { id } = useParams();
  const { profile, loading: authLoading } = useAuth();

  const [donor, setDonor] = useState(null);
  const [donations, setDonations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [noAccess, setNoAccess] = useState(false);

  /* ---------------------------------------------------------
     LOAD DONOR
  --------------------------------------------------------- */
  useEffect(() => {
    if (authLoading || !profile || !id) return;

    const ref = doc(db, "donors", id);

    const unsub = onSnapshot(
      ref,
      (snap) => {
        if (!snap.exists()) {
          setDonor(null);
          setNoAccess(false);
          setLoading(false);
          return;
        }

        const data = { id: snap.id, ...snap.data() };

        if (data.orgId !== profile.orgId) {
          console.warn("❌ Donor belongs to another org");
          setNoAccess(true);
          setDonor(null);
        } else {
          setNoAccess(false);
          setDonor(data);
        }

        setLoading(false);
      },
      (err) => {
        console.error("❌ Donor listener error:", err);
        setLoading(false);
      }
    );

    return () => unsub();
  }, [id, profile, authLoading]);

  /* ---------------------------------------------------------
     LOAD DONATIONS FROM DONOR
  --------------------------------------------------------- */
  useEffect(() => {
    if (!profile || !id) return;

    const qRef = query(
      collection(db, "donations"),
      where("userId", "==", id),
      where("orgId", "==", profile.orgId)
    );

    const unsub = onSnapshot(
      qRef,
      (snap) => {
        const rows = snap.docs.map((d) => ({
          id: d.id,
          ...d.data(),
        }));
        setDonations(rows);
      },
      (err) => console.error("❌ Donation listener error:", err)
    );

    return () => unsub();
  }, [id, profile]);

  /* ---------------------------------------------------------
     STATES
  --------------------------------------------------------- */
  if (authLoading || loading) {
    return (
      <div className="p-6">
        <ListLoadingSpinner />
      </div>
    );
  }

  if (noAccess) {
    return (
      <div className="p-6 max-w-2xl mx-auto">
        <div className="bg-red-50 border border-red-200 text-red-700 rounded-2xl p-4">
          You do not have permission to view this donor.
        </div>
      </div>
    );
  }

  if (!donor) {
    return (
      <div className="p-6 max-w-2xl mx-auto">
        <div className="bg-yellow-50 border border-yellow-200 text-yellow-800 rounded-2xl p-4">
          Donor not found.
        </div>
      </div>
    );
  }

  /* ---------------------------------------------------------
     UI DATA
  --------------------------------------------------------- */
  const totalRaised = donations.reduce((s, d) => s + (d.amount || 0), 0);

  const { name, email, message, imgUrl, createdAt } = donor;

  const createdDate =
    createdAt && createdAt.toDate
      ? createdAt.toDate().toLocaleDateString()
      : "—";

  /* ---------------------------------------------------------
     UI
  --------------------------------------------------------- */
  return (
    <div className="p-6">
      <div className="max-w-5xl mx-auto space-y-6">

        {/* ======================================================
           HERO HEADER
        ====================================================== */}
        <div className="bg-gradient-to-r from-yellow-50 to-slate-50 border border-slate-200 rounded-2xl shadow-sm p-6 sm:p-7 flex flex-col sm:flex-row sm:items-center gap-5">
          <div className="shrink-0">
            <AvatarCircle name={name} imgUrl={imgUrl} size="xl" />
          </div>

          <div className="flex-1 min-w-0">
            <h1 className="text-2xl font-semibold text-slate-900 truncate">
              {name || "Unnamed Donor"}
            </h1>
            <p className="text-sm text-slate-600 truncate">
              {email || "No email provided"}
            </p>
            <p className="mt-1 text-xs text-slate-400">
              Donor profile · Created {createdDate}
            </p>
          </div>
        </div>

        {/* ======================================================
           GRID
        ====================================================== */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

          {/* LEFT SIDE – Stats + Donations */}
          <div className="lg:col-span-2 space-y-6">

            {/* TOTALS */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
              <h2 className="text-sm font-semibold text-slate-800 mb-4">
                Donation Summary
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <CardStatBadge label="Total Donations" value={donations.length} />
                <CardStatBadge label="Total Raised" value={currency(totalRaised)} />
                <CardStatBadge label="Avg Donation" value={currency(donations.length ? totalRaised / donations.length : 0)} />
              </div>
            </div>

            {/* DONATIONS LIST */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
              <h2 className="text-sm font-semibold text-slate-800 mb-4">
                Donation History
              </h2>

              {donations.length === 0 ? (
                <p className="text-slate-500 text-sm">This donor has not made any donations.</p>
              ) : (
                <ul className="divide-y">
                  {donations.map((d) => (
                    <li key={d.id} className="py-3 flex items-center justify-between">
                      <div className="min-w-0">
                        <p className="font-medium text-slate-800">{d.campaignName || "Campaign"}</p>
                        {d.message && (
                          <p className="text-xs text-slate-500 truncate">{d.message}</p>
                        )}
                      </div>
                      <span className="font-semibold text-slate-900">
                        {currency(d.amount)}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </div>

          </div>

          {/* RIGHT SIDE – Meta */}
          <div className="space-y-4">
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">

              <h3 className="text-sm font-semibold text-slate-800 mb-3">
                Donor Details
              </h3>

              <dl className="space-y-2 text-sm">
                <DetailRow label="Name" value={name} />
                <DetailRow label="Email" value={email} />
                <DetailRow label="Org" value={donor.orgId} />
                <DetailRow label="Created" value={createdDate} />
              </dl>

              <div className="mt-4 flex justify-between">
                <Link
                  to="/donors"
                  className="text-xs px-3 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 transition"
                >
                  ← Back to Donors
                </Link>
              </div>

            </div>
          </div>

        </div>

      </div>
    </div>
  );
}

/* ---------------------------------------------------------
   Small reusable component
--------------------------------------------------------- */
function DetailRow({ label, value }) {
  return (
    <div className="flex justify-between gap-3">
      <dt className="text-slate-500">{label}</dt>
      <dd className="text-slate-800 text-right">{value || "—"}</dd>
    </div>
  );
}
