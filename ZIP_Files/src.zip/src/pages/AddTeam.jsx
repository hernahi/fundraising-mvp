// src/pages/AddTeam.jsx
import { useState } from "react";
import { useNavigate } from "react-router-dom";

import { useAuth } from "../context/AuthContext";
import { useToast } from "../components/Toast";

import { db } from "../firebase/config";
import {
  collection,
  addDoc,
  serverTimestamp,
} from "../firebase/firestore";

import ListLoadingSpinner from "../components/ListLoadingSpinner";

export default function AddTeam() {
  const navigate = useNavigate();
  const { profile, loading: authLoading } = useAuth();
  const { push } = useToast();

  const [saving, setSaving] = useState(false);

  const [name, setName] = useState("");
  const [sport, setSport] = useState("");
  const [level, setLevel] = useState("");
  const [location, setLocation] = useState("");
  const [season, setSeason] = useState("");

  if (authLoading) {
    return (
      <div className="p-6">
        <ListLoadingSpinner />
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="p-6 max-w-xl mx-auto">
        <div className="bg-red-50 border border-red-200 text-red-700 rounded-xl p-4">
          You must be signed in to add a team.
        </div>
      </div>
    );
  }

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (saving) return;

    if (!name.trim()) {
      push("Team name is required.", "error");
      return;
    }

    try {
      setSaving(true);

      const payload = {
        name: name.trim(),
        sport: sport.trim() || null,
        level: level.trim() || null,
        location: location.trim() || null,
        season: season.trim() || null,

        orgId: profile.orgId,
        createdAt: serverTimestamp(),
      };

      const ref = collection(db, "teams");
      const docRef = await addDoc(ref, payload);

      push("Team created successfully!", "success");
      navigate(`/teams/${docRef.id}`);
    } catch (err) {
      console.error("❌ Error creating team:", err);
      push("Failed to create team.", "error");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-2xl font-semibold text-slate-800 mb-6">
        Add New Team
      </h1>

      <form
        onSubmit={handleSubmit}
        className="bg-white p-6 rounded-2xl border border-slate-200 shadow space-y-6"
      >
        {/* --------------------------------------------- */}
        {/* TEAM NAME */}
        {/* --------------------------------------------- */}
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Team Name <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            className="input"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            placeholder="e.g. Varsity Football"
          />
        </div>

        {/* --------------------------------------------- */}
        {/* SPORT */}
        {/* --------------------------------------------- */}
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Sport
          </label>
          <input
            type="text"
            className="input"
            value={sport}
            onChange={(e) => setSport(e.target.value)}
            placeholder="e.g. Football, Basketball"
          />
        </div>

        {/* --------------------------------------------- */}
        {/* LEVEL */}
        {/* --------------------------------------------- */}
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Level
          </label>
          <input
            type="text"
            className="input"
            value={level}
            onChange={(e) => setLevel(e.target.value)}
            placeholder="e.g. Varsity, JV, 14U"
          />
        </div>

        {/* --------------------------------------------- */}
        {/* SEASON */}
        {/* --------------------------------------------- */}
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Season
          </label>
          <input
            type="text"
            className="input"
            value={season}
            onChange={(e) => setSeason(e.target.value)}
            placeholder="e.g. Fall 2025"
          />
        </div>

        {/* --------------------------------------------- */}
        {/* LOCATION */}
        {/* --------------------------------------------- */}
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Location
          </label>
          <input
            type="text"
            className="input"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            placeholder="e.g. Downey, CA"
          />
        </div>

        {/* --------------------------------------------- */}
        {/* ACTIONS */}
        {/* --------------------------------------------- */}
        <div className="flex justify-end gap-2 pt-4">
          <button
            type="button"
            onClick={() => navigate("/teams")}
            className="px-3 py-2 rounded-lg border border-slate-300 text-slate-600 hover:bg-slate-100 transition"
          >
            Cancel
          </button>

          <button
            type="submit"
            disabled={saving}
            className="px-4 py-2 rounded-lg bg-yellow-500 text-slate-900 font-medium hover:bg-yellow-400 transition disabled:opacity-50"
          >
            {saving ? "Saving..." : "Create Team"}
          </button>
        </div>
      </form>
    </div>
  );
}
