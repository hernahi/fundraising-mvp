import React, { useEffect, useState } from "react";
import { collection, onSnapshot, query, where } from "firebase/firestore";
import { db } from "../firebase/config";
import safeImageURL from "../utils/safeImage.js";

export default function Coaches({ user }) {
  const [coaches, setCoaches] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!user?.orgId) return;

    const q = query(
      collection(db, "coaches"),
      where("orgId", "==", user.orgId)
    );

    const unsubscribe = onSnapshot(
      q,
      (snap) => {
        const list = [];
        snap.forEach((doc) => list.push({ id: doc.id, ...doc.data() }));
        setCoaches(list);
      },
      (err) => {
        console.error("❌ Coaches listener error:", err);
        setError("Unable to load coaches");
      }
    );

    return () => unsubscribe();
  }, [user?.orgId]);

  return (
    <div>
      <h1>Coaches</h1>
      {error && <p className="error">{error}</p>}

      <div className="coach-grid">
        {coaches.map((c) => (
          <div key={c.id} className="coach-card">
            <img src={safeImageURL(c.photoUrl)} alt="Coach" />
            <h3>{c.name}</h3>
            <p>{c.role || "Coach"}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
