import React, { useEffect, useState } from "react";
import { collection, onSnapshot, query, where } from "firebase/firestore";
import { db } from "../firebase/config";
import safeImageURL from "../utils/safeImage.js";

export default function Campaigns({ user }) {
  const [campaigns, setCampaigns] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!user?.orgId) return;

    const q = query(
      collection(db, "campaigns"),
      where("orgId", "==", user.orgId)
    );

    const unsubscribe = onSnapshot(
      q,
      (snap) => {
        const list = [];
        snap.forEach((doc) => list.push({ id: doc.id, ...doc.data() }));
        setCampaigns(list);
      },
      (err) => {
        console.error("❌ Campaigns listener error:", err);
        setError("Unable to load campaigns");
      }
    );

    return () => unsubscribe();
  }, [user?.orgId]);

  return (
    <div>
      <h1>Campaigns</h1>
      {error && <p className="error">{error}</p>}

      <div className="campaign-list">
        {campaigns.map((c) => (
          <div key={c.id} className="campaign-card">
            <img src={safeImageURL(c.bannerUrl)} alt="Banner" />
            <h3>{c.title}</h3>
            <p>{c.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
