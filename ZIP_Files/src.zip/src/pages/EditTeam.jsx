// src/pages/EditTeam.jsx
import { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";

import { useAuth } from "../context/AuthContext";
import ListLoadingSpinner from "../components/ListLoadingSpinner";
import AvatarCircle from "../components/AvatarCircle";
import { useToast } from "../components/Toast";

import { db } from "../firebase/config";
import {
  doc,
  getDoc,
  updateDoc,
} from "../firebase/firestore";

export default function EditTeam() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { profile, loading: authLoading } = useAuth();
  const { push } = useToast();

  const [team, setTeam] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [name, setName] = useState("");
  const [sport, setSport] = useState("");
  const [level, setLevel] = useState("");
  const [location, setLocation] = useState("");

  /* -------------------------------------------------------------
     LOAD TEAM RECORD (with avatar inheritance hardening)
  ------------------------------------------------------------- */
  useEffect(() => {
    if (authLoading || !profile) return;
    if (!id) return;

    const loadTeam = async () => {
      try {
        const ref = doc(db, "teams", id);
        const snap = await getDoc(ref);

        if (!snap.exists()) {
          setTeam(null);
          setLoading(false);
          return;
        }

        let data = { id: snap.id, ...snap.data() };

        // ⭐ Avatar inheritance hardening
        data.imgUrl =
          data.imgUrl ||
          data.photoURL ||
          null;

        if (data.orgId !== profile.orgId) {
          push("You do not have access to edit this team.", "error");
          setTeam(null);
          setLoading(false);
          return;
        }

        setTeam(data);

        setName(data.name || "");
        setSport(data.sport || "");
        setLevel(data.level || "");
        setLocation(data.location || "");

        setLoading(false);
      } catch (err) {
        console.error("❌ Error loading team:", err);
        push("Failed to load team.", "error");
        setLoading(false);
      }
    };

    loadTeam();
  }, [authLoading, profile, id, push]);

  /* -------------------------------------------------------------
     SAVE UPDATES
  ------------------------------------------------------------- */
  const handleSave = async () => {
    if (!team) return;

    setSaving(true);
    try {
      const ref = doc(db, "teams", team.id);

      await updateDoc(ref, {
        name: name.trim(),
        sport: sport.trim(),
        level: level.trim(),
        location: location.trim(),
      });

      push("Team updated successfully!", "success");
      navigate(`/teams/${team.id}`);
    } catch (err) {
      console.error("❌ Failed to update team:", err);
      push("Failed to update team.", "error");
    }
    setSaving(false);
  };

  /* -------------------------------------------------------------
     STATES
  ------------------------------------------------------------- */
  if (authLoading || loading) {
    return (
      <div className="p-6">
        <ListLoadingSpinner />
      </div>
    );
  }

  if (!team) {
    return (
      <div className="p-6 max-w-xl mx-auto">
        <div className="bg-red-50 border border-red-200 text-red-700 rounded-2xl p-4">
          Team not found or no access.
        </div>
      </div>
    );
  }

  /* -------------------------------------------------------------
     UI — EDIT FORM
  ------------------------------------------------------------- */
  return (
    <div className="p-6">
      <div className="max-w-3xl mx-auto space-y-6">

        {/* HEADER / HERO */}
        <div className="bg-gradient-to-r from-yellow-50 via-white to-slate-50 border border-slate-200 rounded-2xl shadow-sm p-6 flex items-center gap-5">
          <AvatarCircle
            name={team.name}
            imgUrl={team.imgUrl} // ⭐ hardened field
            size="xl"
          />

          <div className="flex-1 min-w-0">
            <h1 className="text-2xl font-semibold text-slate-900 truncate">
              Edit Team: {team.name}
            </h1>
            <p className="text-sm text-slate-600 truncate">
              Update team information
            </p>
          </div>

          <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-indigo-50 text-indigo-700 border border-indigo-200">
            Edit Mode
          </span>
        </div>

        {/* FORM */}
        <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-6 space-y-6">

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-700">
                Team Name
              </label>
              <input
                type="text"
                className="mt-1 w-full rounded-lg border-slate-300 shadow-sm"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g., Varsity Football"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700">
                Sport
              </label>
              <input
                type="text"
                className="mt-1 w-full rounded-lg border-slate-300 shadow-sm"
                value={sport}
                onChange={(e) => setSport(e.target.value)}
                placeholder="e.g., Football"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700">
                Level
              </label>
              <input
                type="text"
                className="mt-1 w-full rounded-lg border-slate-300 shadow-sm"
                value={level}
                onChange={(e) => setLevel(e.target.value)}
                placeholder="e.g., Varsity"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700">
                Location
              </label>
              <input
                type="text"
                className="mt-1 w-full rounded-lg border-slate-300 shadow-sm"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="e.g., Downey, CA"
              />
            </div>
          </div>

          {/* ACTIONS */}
          <div className="flex justify-between items-center pt-4 border-t border-slate-200">

            <Link
              to={`/teams/${team.id}`}
              className="text-xs px-3 py-2 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 transition"
            >
              ← Cancel
            </Link>

            <button
              onClick={handleSave}
              disabled={saving}
              className="text-sm px-4 py-2 rounded-lg bg-yellow-500 text-slate-900 hover:bg-yellow-400 transition disabled:opacity-50"
            >
              {saving ? "Saving…" : "Save Changes"}
            </button>

          </div>
        </div>

      </div>
    </div>
  );
}
