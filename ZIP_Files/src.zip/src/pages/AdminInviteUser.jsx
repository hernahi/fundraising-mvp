import { useState } from "react";
import { db } from "../firebase/config";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function AdminInviteUser() {
  const { profile } = useAuth();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    email: "",
    role: "coach",
    orgId: "",
    teamId: "",
  });

  if (profile?.role !== "admin") {
    return <div className="p-6 text-red-500">Access denied</div>;
  }

  const submit = async (e) => {
    e.preventDefault();
    try {
      await addDoc(collection(db, "users"), {
        email: form.email.toLowerCase(),
        role: form.role,
        orgId: form.orgId || null,
        teamId: form.teamId || null,
        status: "invited",
        invitedAt: serverTimestamp(),
      });

      window.toast?.("✅ User invited", "success");
      navigate("/admin/users");
    } catch (err) {
      console.error(err);
      window.toast?.("❌ Error inviting user", "error");
    }
  };

  return (
    <div className="p-6 max-w-lg mx-auto bg-white rounded-xl shadow">
      <h1 className="text-xl font-bold mb-4">Invite New User</h1>

      <form onSubmit={submit} className="space-y-4">
        <div>
          <label className="block text-sm mb-1">Email</label>
          <input
            className="w-full border rounded px-3 py-2"
            type="email"
            required
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
          />
        </div>

        <div>
          <label className="block text-sm mb-1">Role</label>
          <select
            className="w-full border rounded px-3 py-2"
            value={form.role}
            onChange={(e) => setForm({ ...form, role: e.target.value })}
          >
            <option value="coach">Coach</option>
            <option value="athlete">Athlete</option>
            <option value="admin">Admin</option>
          </select>
        </div>

        <div>
          <label className="block text-sm mb-1">Org (school)</label>
          <input
            className="w-full border rounded px-3 py-2"
            value={form.orgId}
            placeholder="ex: downey-hs"
            onChange={(e) => setForm({ ...form, orgId: e.target.value })}
          />
        </div>

        <div>
          <label className="block text-sm mb-1">Team</label>
          <input
            className="w-full border rounded px-3 py-2"
            value={form.teamId}
            placeholder="ex: football"
            onChange={(e) => setForm({ ...form, teamId: e.target.value })}
          />
        </div>

        <button className="w-full bg-yellow-400 py-2 rounded font-semibold hover:brightness-110">
          Invite User
        </button>
      </form>
    </div>
  );
}
