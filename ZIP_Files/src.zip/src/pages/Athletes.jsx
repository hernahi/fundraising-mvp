import React, { useEffect, useState } from "react";
import { collection, onSnapshot, query, where } from "firebase/firestore";
import { db } from "../firebase/config";
import safeImageURL from "../utils/safeImage.js";

export default function Athletes({ user }) {
  const [athletes, setAthletes] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!user?.teamId) return;

    const q = query(
      collection(db, "athletes"),
      where("teamId", "==", user.teamId)
    );

    const unsubscribe = onSnapshot(
      q,
      (snap) => {
        const list = [];
        snap.forEach((doc) => list.push({ id: doc.id, ...doc.data() }));
        setAthletes(list);
      },
      (err) => {
        console.error("❌ Athletes listener error:", err);
        setError("Unable to load athletes");
      }
    );

    return () => unsubscribe();
  }, [user?.teamId]);

  return (
    <div>
      <h1>Athletes</h1>
      {error && <p className="error">{error}</p>}

      <div className="athlete-grid">
        {athletes.map((a) => (
          <div key={a.id} className="athlete-card">
            <img src={safeImageURL(a.photoUrl)} alt="Athlete" />
            <h3>{a.name}</h3>
            <p>Number: {a.jerseyNumber}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
