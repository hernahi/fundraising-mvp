// src/pages/CampaignDetail.jsx
import { useParams, Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { currency } from "../utils/currency";
import { useAuth } from "../context/AuthContext";
import AvatarCircle from "../components/AvatarCircle";
import ListLoadingSpinner from "../components/ListLoadingSpinner";

// Firebase
import { db } from "../firebase/config";
import {
  doc,
  collection,
  query,
  where,
  onSnapshot,
  getDocs,
} from "firebase/firestore";

// Components
import DonationForm from "../components/DonationForm";
import ShareBlock from "../components/ShareBlock";
import Leaderboard from "../components/Leaderboard";
import AssignAthletesModal from "../components/AssignAthletesModal";
import RemoveAthleteMenu from "../components/RemoveAthleteMenu";

export default function CampaignDetail() {
  const { id } = useParams();
  const { profile } = useAuth();

  const [campaign, setCampaign] = useState(null);
  const [donations, setDonations] = useState([]);
  const [athletes, setAthletes] = useState([]);
  const [coaches, setCoaches] = useState([]);
  const [pivotByAthlete, setPivotByAthlete] = useState({});
  const [loading, setLoading] = useState(true);
  const [showAssignModal, setShowAssignModal] = useState(false);

  /* --------------------------------------------------------
     1. Load Campaign
  -------------------------------------------------------- */
  useEffect(() => {
    if (!id || !profile) return;
    const unsub = onSnapshot(
      doc(db, "campaigns", id),
      (snap) => {
        if (!snap.exists()) {
          setCampaign(null);
          setLoading(false);
          return;
        }
        const data = { id: snap.id, ...snap.data() };
        if (data.orgId !== profile.orgId) {
          setCampaign(null);
          setLoading(false);
          return;
        }
        setCampaign(data);
      },
      (err) => console.error("❌ Campaign listener error:", err)
    );
    return () => unsub();
  }, [id, profile]);

  /* --------------------------------------------------------
     2. Load Donations (org-filtered)
  -------------------------------------------------------- */
  useEffect(() => {
    if (!id || !profile) return;
    const qDon = query(
      collection(db, "donations"),
      where("campaignId", "==", id),
      where("orgId", "==", profile.orgId)
    );

    const unsub = onSnapshot(
      qDon,
      (snap) => setDonations(snap.docs.map((d) => ({ id: d.id, ...d.data() }))),
      (err) => console.error("❌ Donations listener error:", err)
    );

    return () => unsub();
  }, [id, profile]);

  /* --------------------------------------------------------
     3. Load Coaches Assigned to Campaign (via coaches/{uid})
  -------------------------------------------------------- */
  useEffect(() => {
    if (!id || !profile) return;

    const qCoaches = query(
      collection(db, "coaches"),
      where("campaignId", "==", id),
      where("orgId", "==", profile.orgId)
    );

    const unsub = onSnapshot(
      qCoaches,
      async (snap) => {
        const coachDocs = snap.docs.map((d) => ({ id: d.id, ...d.data() }));

        // Resolve user profile for each coach
        const resolved = [];
        for (const c of coachDocs) {
          if (!c.userId) continue;
          const userSnap = await getDocs(
            query(
              collection(db, "users"),
              where("__name__", "==", c.userId),
              where("orgId", "==", profile.orgId)
            )
          );
          const user = userSnap.docs[0]?.data() || {};
          resolved.push({
            ...c,
            name: user.displayName || user.name || "Coach",
            email: user.email || "",
            imgUrl: user.photoURL || user.imgUrl || "",
          });
        }

        setCoaches(resolved);
      },
      (err) => console.error("❌ Coaches listener error:", err)
    );

    return () => unsub();
  }, [id, profile]);

  /* --------------------------------------------------------
     4. Load Athlete Pivots + Resolve Athlete Profiles
  -------------------------------------------------------- */
  useEffect(() => {
    if (!id || !profile) return;

    const qPiv = query(
      collection(db, "campaignAthletes"),
      where("campaignId", "==", id),
      where("orgId", "==", profile.orgId)
    );

    const unsub = onSnapshot(
      qPiv,
      async (pivotSnap) => {
        const pivotIds = pivotSnap.docs.map((d) => ({
          pivotId: d.id,
          athleteId: d.data().athleteId,
        }));

        // Map pivot by athleteId
        const pivotMap = {};
        for (const p of pivotIds) {
          if (p.athleteId) pivotMap[p.athleteId] = p.pivotId;
        }
        setPivotByAthlete(pivotMap);

        const athleteIds = pivotIds
          .map((p) => p.athleteId)
          .filter(Boolean);

        if (athleteIds.length === 0) {
          setAthletes([]);
          setLoading(false);
          return;
        }

        // Firestore allows max 10 per IN query → batch them
        const batches = [];
        while (athleteIds.length) batches.push(athleteIds.splice(0, 10));

        const final = [];
        for (const group of batches) {
          const snap = await getDocs(
            query(
              collection(db, "athletes"),
              where("__name__", "in", group),
              where("orgId", "==", profile.orgId)
            )
          );
          final.push(...snap.docs.map((a) => ({ id: a.id, ...a.data() })));
        }

        setAthletes(final);
        setLoading(false);
      },
      (err) => console.error("❌ Pivot listener error:", err)
    );

    return () => unsub();
  }, [id, profile]);

  /* --------------------------------------------------------
     LOADING STATE
  -------------------------------------------------------- */
  if (loading || !campaign)
    return <ListLoadingSpinner />;

  const raised = donations.reduce((s, d) => s + (d.amount || 0), 0);
  const net = raised - Math.round(raised * (campaign.feePct || 0));

  /* --------------------------------------------------------
     RENDER
  -------------------------------------------------------- */
  return (
    <div className="p-6 space-y-6">

      {/* ===== Header ===== */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-slate-800">
            {campaign.title || campaign.name}
          </h1>
          <p className="text-sm text-slate-600">
            Goal {currency(campaign.goal)} · Raised {currency(raised)} · Net{" "}
            {currency(net)}
          </p>
        </div>

        <div className="flex gap-3">
          <button
            onClick={() => setShowAssignModal(true)}
            className="px-3 py-2 rounded-lg border border-yellow-400 text-yellow-600 hover:bg-yellow-400 hover:text-slate-900 transition text-sm font-medium"
          >
            Assign Athletes
          </button>
          <ShareBlock campaign={campaign} />
        </div>
      </div>

      {/* ===== Coaches ===== */}
      <div className="bg-white rounded-2xl shadow p-4">
        <h2 className="font-medium mb-4">Assigned Coaches</h2>
        {coaches.length === 0 ? (
          <p className="text-slate-500 text-sm">No coaches assigned.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {coaches.map((c) => (
              <div
                key={c.id}
                className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center gap-3"
              >
                <AvatarCircle name={c.name} imgUrl={c.imgUrl} size={10} />
                <div>
                  <p className="font-medium text-slate-800">{c.name}</p>
                  <p className="text-xs text-slate-500">{c.email}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ===== Athletes ===== */}
      <div className="bg-white rounded-2xl shadow p-4">
        <h2 className="font-medium mb-4">Assigned Athletes</h2>
        {athletes.length === 0 ? (
          <p className="text-slate-500 text-sm">
            No athletes assigned yet.
            <button
              onClick={() => setShowAssignModal(true)}
              className="ml-2 text-yellow-600 underline hover:text-yellow-500"
            >
              Assign athletes →
            </button>
          </p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {athletes.map((a) => (
              <div
                key={a.id}
                className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between hover:shadow-[0_0_12px_rgba(250,204,21,0.35)] transition"
              >
                <div className="flex items-center gap-3">
                  <AvatarCircle name={a.name} imgUrl={a.imgUrl} size={10} />
                  <div>
                    <p className="font-medium text-slate-800">{a.name}</p>
                    <p className="text-xs text-slate-500">{a.team}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Link
                    to={`/athletes/${a.id}`}
                    className="text-xs text-yellow-600 underline hover:text-yellow-500"
                  >
                    View
                  </Link>
                  {pivotByAthlete[a.id] && (
                    <RemoveAthleteMenu
                      pivotId={pivotByAthlete[a.id]}
                      athleteName={a.name}
                    />
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ===== Donations ===== */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 p-4 bg-white rounded-2xl shadow">
          <h2 className="font-medium mb-4">Recent Donations</h2>
          <ul className="divide-y">
            {donations.slice(0, 10).map((d) => (
              <li key={d.id} className="py-3 flex items-center justify-between">
                <div className="min-w-0">
                  <div className="font-medium text-slate-800">
                    {d.donorName}
                  </div>
                  {d.message && (
                    <div className="text-xs text-slate-600 truncate">
                      {d.message}
                    </div>
                  )}
                </div>
                <span className="ml-4 shrink-0 font-semibold text-slate-800">
                  ${d.amount}
                </span>
              </li>
            ))}
          </ul>
        </div>

        <div className="p-4 bg-white rounded-2xl shadow">
          <h2 className="font-medium mb-4">Record a Donation</h2>
          <DonationForm campaignId={campaign.id} athleteOptions={athletes} />
        </div>
      </div>

      {/* ===== Leaderboard ===== */}
      <div className="p-4 bg-white rounded-2xl shadow">
        <h2 className="font-medium mb-4">Leaderboard</h2>
        <Leaderboard campaignId={campaign.id} />
      </div>

      {showAssignModal && (
        <AssignAthletesModal
          campaignId={campaign.id}
          onClose={() => setShowAssignModal(false)}
        />
      )}
    </div>
  );
}
