// src/pages/Donors.jsx
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

import HeaderActions from "../components/HeaderActions";
import ListLoadingSpinner from "../components/ListLoadingSpinner";
import ListEmptyState from "../components/ListEmptyState";
import CardUserAvatar from "../components/CardUserAvatar";
import CardStatBadge from "../components/CardStatBadge";

import { useToast } from "../components/Toast";
import { useAuth } from "../context/AuthContext";

import { db } from "../firebase/config";
import {
  collection,
  onSnapshot,
  query,
  where,
  orderBy,
} from "../firebase/firestore";

export default function Donors() {
  const { profile, loading: authLoading } = useAuth();
  const { push } = useToast();

  const [donors, setDonors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState("");

  useEffect(() => {
    if (authLoading || !profile) return;

    const ref = collection(db, "donors");
    const q = query(
      ref,
      where("orgId", "==", profile.orgId),
      orderBy("createdAt", "desc")
    );

    const unsub = onSnapshot(
      q,
      (snap) => {
        const items = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
        setDonors(items);
        setLoading(false);
        setLastUpdated(new Date().toLocaleTimeString());
      },
      (err) => {
        console.error("❌ Donors listener error:", err);
        push("Failed to load donors.", "error");
        setLoading(false);
      }
    );

    return () => unsub();
  }, [authLoading, profile, push]);

  if (authLoading) {
    return (
      <div className="p-6">
        <ListLoadingSpinner />
      </div>
    );
  }

  return (
    <div className="p-6">
      <HeaderActions
        title="Donors"
        addLabel={<Link to="/donors/new">+ Add Donor</Link>}
        exportLabel={null}
        lastUpdated={lastUpdated}
      />

      {loading ? (
        <ListLoadingSpinner />
      ) : donors.length === 0 ? (
        <ListEmptyState message="No donors found." />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
          {donors.map((d) => (
            <div
              key={d.id}
              className="bg-white rounded-2xl border border-slate-200 p-4 shadow hover:shadow-yellow-300/40 transition-all duration-300"
            >
              <div className="flex items-center gap-3">
                <CardUserAvatar name={d.name} imgUrl={d.imgUrl} />

                <div className="min-w-0">
                  <div className="font-semibold text-slate-800">{d.name}</div>
                  <div className="text-xs text-slate-500">
                    {d.email || "No email"}
                  </div>
                </div>
              </div>

              <div className="text-[10px] text-slate-400 mt-1 select-all">
                ID: {d.id}
              </div>

              <div className="mt-3 flex gap-2 flex-wrap">
                <CardStatBadge
                  label="Total Donations"
                  value={d.totalDonations || 0}
                />
                <CardStatBadge
                  label="Last Donation"
                  value={d.lastDonationDate || "—"}
                />
              </div>

              <div className="mt-4 flex justify-end">
                <Link
                  to={`/donors/${d.id}`}
                  className="text-sm px-3 py-1.5 rounded-lg border border-yellow-400 text-yellow-600 hover:bg-yellow-400 hover:text-slate-900 transition"
                >
                  View →
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
