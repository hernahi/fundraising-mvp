import React, { useEffect, useState } from "react";
import { doc, getDoc } from "firebase/firestore";
import { db } from "../firebase/config";
import safeImageURL from "../utils/safeImage.js";
import { loadStripe } from "@stripe/stripe-js";

export default function PublicDonate() {
  const [campaign, setCampaign] = useState(null);
  const [team, setTeam] = useState(null);
  const [org, setOrg] = useState(null);
  const [loading, setLoading] = useState(true);
  const [amount, setAmount] = useState("");
  const [error, setError] = useState("");
  const [checkoutLoading, setCheckoutLoading] = useState(false);

  const params = new URLSearchParams(window.location.search);
  const campaignId = window.location.pathname.split("/").pop();

  useEffect(() => {
    async function load() {
      try {
        console.log("Fetching campaign:", campaignId);
        const campaignRef = doc(db, "campaigns", campaignId);
        const snapshot = await getDoc(campaignRef);

        if (!snapshot.exists()) {
          console.error("❌ Campaign not found in Firestore");
          setError("Campaign not found");
          setLoading(false);
          return;
        }

        const data = snapshot.data();
        setCampaign(data);

        const teamRef = doc(db, "teams", data.teamId);
        const teamSnap = await getDoc(teamRef);
        if (teamSnap.exists()) {
          setTeam(teamSnap.data());
        }

        if (teamSnap.exists() && teamSnap.data().orgId) {
          const orgRef = doc(db, "organizations", teamSnap.data().orgId);
          const orgSnap = await getDoc(orgRef);
          if (orgSnap.exists()) {
            setOrg(orgSnap.data());
          }
        }
      } catch (err) {
        console.error("🔥 Load error:", err);
        setError("Failed to load campaign");
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [campaignId]);

  async function startCheckout() {
    if (!amount || amount < 5) {
      setError("Minimum donation is $5");
      return;
    }

    setCheckoutLoading(true);

    try {
      const stripe = await loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

      const res = await fetch(
        `${import.meta.env.VITE_API_URL}/create-checkout-session`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            amount: parseInt(amount, 10),
            campaignId,
          }),
        }
      );

      const session = await res.json();

      if (!session.id) {
        console.error("❌ No session returned:", session);
        setError("Payment failed.");
        setCheckoutLoading(false);
        return;
      }

      await stripe.redirectToCheckout({ sessionId: session.id });
    } catch (err) {
      console.error("❌ Checkout error:", err);
      setError("Unable to start checkout");
    } finally {
      setCheckoutLoading(false);
    }
  }

  if (loading) return <p>Loading campaign...</p>;
  if (error) return <p className="error">{error}</p>;

  return (
    <div className="public-donate-container">
      <h1>{campaign.title}</h1>
      {team && <h2>{team.name}</h2>}
      {org && <h3>{org.name}</h3>}

      <img
        className="banner"
        src={safeImageURL(campaign.bannerUrl)}
        alt="Campaign Banner"
      />

      <div className="donation-box">
        <input
          type="number"
          placeholder="Donation amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />

        <button disabled={checkoutLoading} onClick={startCheckout}>
          {checkoutLoading ? "Processing..." : "Donate"}
        </button>

        {error && <p className="error">{error}</p>}
      </div>
    </div>
  );
}
