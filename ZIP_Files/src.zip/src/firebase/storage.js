// Placeholder Storage helper
export const noop = () => {};
