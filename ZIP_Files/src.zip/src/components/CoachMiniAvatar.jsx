// src/components/CoachMiniAvatar.jsx
import AvatarCircle from "./AvatarCircle";
import { safeImageURL } from "../utils/safeImage";

/**
 * CoachMiniAvatar
 * The compact avatar renderer used in Sidebar and small UI clusters.
 *
 * Responsibilities:
 * - Fully CSP-safe image sanitation via safeImageURL()
 * - Guaranteed initials fallback identical to AvatarCircle
 * - Unified sizing ("xs" or "sm" recommended)
 */

export default function CoachMiniAvatar({
  name = "",
  imgUrl = null,
  size = "xs",
}) {
  const safeUrl = safeImageURL(imgUrl);

  return (
    <div className="flex items-center gap-2">
      <AvatarCircle
        name={name}
        imgUrl={safeUrl}
        size={size}
      />
    </div>
  );
}
