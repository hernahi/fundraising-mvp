// src/components/CampaignMiniAvatar.jsx
import SafeAvatar from "./SafeAvatar";

export default function CampaignMiniAvatar({ name, imgUrl }) {
  return (
    <SafeAvatar
      name={name}
      imgUrl={imgUrl}
      size={36}
      className="border border-slate-300"
    />
  );
}
