// src/components/InviteCoachModal.jsx
import { useState } from "react";
import { httpsCallable } from "firebase/functions";
import { functions } from "../firebase/config";
import { useToast } from "./Toast";

export default function InviteCoachModal({ coach, onClose }) {
  const { push } = useToast();
  const [email, setEmail] = useState(coach.email || "");
  const [sending, setSending] = useState(false);

  const sendInvite = async () => {
    if (!email) return push("Email is required.", "error");

    try {
      setSending(true);

      const sendFn = httpsCallable(functions, "sendCoachInvite");
      await sendFn({
        email,
        coachId: coach.id,
        name: coach.name,
        orgId: coach.orgId,
      });

      push("Invitation sent successfully!", "success");
      onClose();
    } catch (err) {
      console.error("Invite error:", err);
      push("Failed to send invitation", "error");
      setSending(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-lg p-6 w-full max-w-md">

        <h2 className="text-xl font-bold mb-4 text-slate-800">
          Invite Coach
        </h2>

        <label className="block text-sm font-medium text-slate-700 mb-1">
          Email Address
        </label>
        <input
          className="w-full p-2 border rounded-lg"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        <div className="flex justify-end gap-3 mt-6">
          <button
            onClick={onClose}
            className="px-4 py-2 border border-slate-300 text-slate-600 rounded-lg"
          >
            Cancel
          </button>

          <button
            onClick={sendInvite}
            disabled={sending}
            className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:bg-blue-300"
          >
            {sending ? "Sending..." : "Send Invite"}
          </button>
        </div>
      </div>
    </div>
  );
}
