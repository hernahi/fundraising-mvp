// src/components/AssignCoachToTeamModal.jsx
import { useEffect, useState } from "react";
import { collection, query, where, getDocs, addDoc } from "firebase/firestore";
import { db } from "../firebase/config";
import { useToast } from "./Toast";
import ListLoadingSpinner from "./ListLoadingSpinner";

export default function AssignCoachToTeamModal({ teamId, orgId, onClose }) {
  const { push } = useToast();
  const [loading, setLoading] = useState(true);
  const [coaches, setCoaches] = useState([]);
  const [selectedCoach, setSelectedCoach] = useState("");

  useEffect(() => {
    const load = async () => {
      try {
        const ref = collection(db, "users");
        const q = query(
          ref,
          where("role", "==", "coach"),
          where("orgId", "==", orgId)
        );

        const snap = await getDocs(q);
        setCoaches(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
      } catch (err) {
        console.error("Failed to load coaches:", err);
        push("Failed to load coaches", "error");
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [orgId, push]);

  const handleAssign = async () => {
    if (!selectedCoach) {
      push("Please select a coach", "warning");
      return;
    }

    try {
      await addDoc(collection(db, "teamCoaches"), {
        teamId,
        coachId: selectedCoach,
        orgId,
        createdAt: new Date().toISOString(),
      });

      push("Coach assigned!", "success");
      onClose();
    } catch (err) {
      console.error("Assign failed:", err);
      push("Failed to assign coach", "error");
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-lg p-6 w-full max-w-md">

        <h2 className="text-xl font-bold text-slate-800 mb-4">
          Assign Coach to Team
        </h2>

        {loading ? (
          <ListLoadingSpinner />
        ) : (
          <>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Select a Coach
            </label>
            <select
              className="w-full border rounded-lg p-2"
              value={selectedCoach}
              onChange={(e) => setSelectedCoach(e.target.value)}
            >
              <option value="">-- Select Coach --</option>
              {coaches.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.displayName || c.email}
                </option>
              ))}
            </select>

            <div className="flex justify-end gap-3 mt-6">
              <button
                onClick={onClose}
                className="px-4 py-2 border border-slate-300 text-slate-600 rounded-lg"
              >
                Cancel
              </button>

              <button
                onClick={handleAssign}
                className="px-4 py-2 bg-yellow-400 text-slate-900 rounded-lg hover:bg-yellow-500"
              >
                Assign
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
