// src/components/Topbar.jsx
import { useAuth } from "../context/AuthContext";
import CoachMiniAvatar from "./CoachMiniAvatar";

export default function Topbar() {
  const { profile, logout } = useAuth();

  // -------------------------------------------------------------
  //  Unified Safe Avatar Pipeline
  // -------------------------------------------------------------
  // PRIORITY:
  // 1) profile.photoURL  — Google → Firestore
  // 2) profile.imgUrl    — legacy/file uploads
  // 3) null              — triggers fallback initials avatar
  const avatarUrl =
    profile?.photoURL?.trim?.() ||
    profile?.imgUrl?.trim?.() ||
    null;

  // Unified display name fallback
  const displayName =
    profile?.displayName ||
    profile?.name ||
    profile?.email ||
    "User";

  return (
    <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6">
      
      <div className="text-lg font-semibold text-slate-700">
        Fundraising MVP
      </div>

      <div className="flex items-center gap-4">
        <CoachMiniAvatar
          name={displayName}
          imgUrl={avatarUrl}
        />

        <button
          onClick={logout}
          className="text-sm px-3 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-100 transition"
        >
          Logout
        </button>
      </div>

    </header>
  );
}
