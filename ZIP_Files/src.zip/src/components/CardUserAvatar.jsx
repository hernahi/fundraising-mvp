// src/components/CardUserAvatar.jsx
import AvatarCircle from "./AvatarCircle";

/**
 * CardUserAvatar
 * ------------------------------------------
 * Hardened avatar component for list + card UIs.
 * Safe against:
 *  - malformed URLs
 *  - blob/javascript/data URL injection
 *  - missing / null image URLs
 *  - referrer leakage
 *  - CSP image-src restrictions
 *
 * Uses AvatarCircle for all sanitization + fallback initials.
 */

export default function CardUserAvatar({ name, imgUrl, size = "md" }) {
  return (
    <div className="flex items-center">
      <AvatarCircle
        name={name}
        imgUrl={imgUrl}
        size={size}   // "sm" | "md" | "lg"
      />
    </div>
  );
}
