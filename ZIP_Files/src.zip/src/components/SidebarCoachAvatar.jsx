// src/components/SidebarCoachAvatar.jsx
import SafeAvatar from "./SafeAvatar";

export default function SidebarCoachAvatar({ name, imgUrl }) {
  return <SafeAvatar name={name} imgUrl={imgUrl} size={40} />;
}
