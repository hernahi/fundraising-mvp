export default function StatCard({ title, value, children }){
  return (
    <div className="p-4 bg-white rounded-2xl shadow flex flex-col gap-2">
      <div className="text-sm text-gray-600">{title}</div>
      <div className="text-2xl font-semibold">{value}</div>
      {children}
    </div>
  );
}
