// src/components/CardUserAvatarSmall.jsx
import AvatarCircle from "./AvatarCircle";

export default function CardUserAvatarSmall({ name, imgUrl }) {
  return (
    <div className="flex items-center gap-2">
      <AvatarCircle name={name} imgUrl={imgUrl} size="sm" />
      <span className="text-sm text-slate-800 truncate">{name}</span>
    </div>
  );
}
