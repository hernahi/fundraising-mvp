import { LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

export function ThemedLineChart({ data, dataKey, label }) {
  return (
    <div className="bg-slate-800 border border-slate-700 rounded-2xl p-4 shadow-[0_0_12px_rgba(250,204,21,0.1)]">
      <h3 className="text-yellow-400 font-semibold text-sm mb-3">{label}</h3>
      <ResponsiveContainer width="100%" height={250}>
        <LineChart data={data}>
          <CartesianGrid stroke="#334155" strokeDasharray="3 3" />
          <XAxis dataKey="name" stroke="#94a3b8" tick={{ fill: '#94a3b8' }} />
          <YAxis stroke="#94a3b8" tick={{ fill: '#94a3b8' }} />
          <Tooltip
            contentStyle={{
              backgroundColor: '#0f172a',
              border: '1px solid #facc15',
              borderRadius: '0.75rem',
              color: '#facc15',
            }}
          />
          <Line
            type="monotone"
            dataKey={dataKey}
            stroke="#facc15"
            strokeWidth={2}
            dot={{ r: 4, stroke: '#facc15', strokeWidth: 2 }}
            activeDot={{ r: 6, fill: '#facc15' }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
