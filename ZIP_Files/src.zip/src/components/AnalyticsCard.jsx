export default function AnalyticsCard({ title, value, tooltip }) {
  return (
    <div
      className="bg-slate-800 p-4 rounded-xl border border-slate-700 text-center hover:shadow-[0_0_15px_rgba(250,204,21,0.3)] hover:border-yellow-400 transition-all duration-300"
      title={tooltip}
    >
      <h4 className="text-slate-400 text-sm mb-1">{title}</h4>
      <p className="text-2xl font-bold text-yellow-400">{value}</p>
    </div>
  );
}
