export default function UserRoleBadge({ role }) {
  const colors = {
    admin: "bg-purple-600",
    coach: "bg-blue-600",
    athlete: "bg-green-600",
    parent: "bg-orange-500",
    donor: "bg-gray-600",
  };

  return (
    <span className={`text-white text-xs px-2 py-1 rounded ${colors[role] || "bg-gray-500"}`}>
      {role}
    </span>
  );
}
