// src/components/Sidebar.jsx
import { NavLink } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

import {
  HomeIcon,
  UserGroupIcon,
  BanknotesIcon,
  UserCircleIcon,
  Cog6ToothIcon,
  UserPlusIcon,
  UserIcon,
  TrophyIcon,
  UsersIcon,
} from "@heroicons/react/24/outline";

import CoachMiniAvatar from "./CoachMiniAvatar";

export default function Sidebar() {
  const { profile } = useAuth();
  const isAdmin = profile?.role === "admin";

  // Global avatar logic: always pick REAL Google photo first
  const avatarUrl =
    profile?.photoURL ||
    profile?.imgUrl ||
    null;

  return (
    <div className="w-64 bg-white border-r border-slate-200 h-screen fixed left-0 top-0 flex flex-col z-20">

      {/* Profile Header */}
      <div className="p-5 flex items-center gap-3 border-b border-slate-200">
        <CoachMiniAvatar
          name={profile?.displayName || profile?.name || profile?.email}
          imgUrl={avatarUrl}
        />

        <div className="min-w-0">
          <p className="font-semibold text-slate-800 truncate">
            {profile?.displayName || profile?.name || "User"}
          </p>
          <p className="text-xs text-slate-500 truncate">
            {profile?.role || "role"}
          </p>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto">
        <ul className="p-3 space-y-1">
          <SidebarItem to="/" icon={<HomeIcon className="w-5" />} label="Dashboard" />

          <SidebarItem to="/campaigns" icon={<BanknotesIcon className="w-5" />} label="Campaigns" />

          <SidebarItem to="/athletes" icon={<UserGroupIcon className="w-5" />} label="Athletes" />

          <SidebarItem to="/donors" icon={<UserCircleIcon className="w-5" />} label="Donors" />

          <SidebarItem to="/coaches" icon={<UserIcon className="w-5" />} label="Coaches" />

          <SidebarItem to="/teams" icon={<UsersIcon className="w-5" />} label="Teams" />

          <SidebarItem to="/leaderboard-global" icon={<TrophyIcon className="w-5" />} label="Global Leaderboard" />

          {isAdmin && (
            <>
              <div className="pt-4 pb-2 px-3 text-xs uppercase text-slate-400">
                Admin
              </div>

              <SidebarItem
                to="/admin/users"
                icon={<UserGroupIcon className="w-5" />}
                label="Users"
              />
              <SidebarItem
                to="/admin/invite"
                icon={<UserPlusIcon className="w-5" />}
                label="Invite User"
              />
              <SidebarItem
                to="/settings"
                icon={<Cog6ToothIcon className="w-5" />}
                label="Settings"
              />
            </>
          )}
        </ul>
      </nav>
    </div>
  );
}

function SidebarItem({ to, icon, label }) {
  return (
    <li>
      <NavLink
        to={to}
        className={({ isActive }) =>
          [
            "flex items-center gap-3 px-3 py-2 rounded-lg transition hover:bg-yellow-50",
            isActive
              ? "bg-yellow-100 text-yellow-700 font-medium border border-yellow-200"
              : "text-slate-700",
          ].join(" ")
        }
      >
        {icon}
        <span className="truncate">{label}</span>
      </NavLink>
    </li>
  );
}
