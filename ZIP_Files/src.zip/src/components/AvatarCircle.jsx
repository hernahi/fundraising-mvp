// src/components/AvatarCircle.jsx
import { safeImageURL } from "../utils/safeImage";

/**
 * AvatarCircle
 * Production-grade, CSP-safe avatar renderer.
 *
 * Rules:
 * - Sanitizes all image URLs via safeImageURL()
 * - Fallback to initials if photo blocked/absent
 * - Prevents broken image flash
 */

export default function AvatarCircle({
  name = "",
  imgUrl = null,
  size = "md",
}) {
  // Enforce safe image URL
  const safeUrl = safeImageURL(imgUrl);

  const initials = name
    ? name
        .split(" ")
        .slice(0, 2)
        .map((n) => n[0]?.toUpperCase())
        .join("")
    : "?";

  const sizeClass = {
    sm: "w-8 h-8 text-xs",
    md: "w-12 h-12 text-sm",
    lg: "w-16 h-16 text-base",
    xl: "w-24 h-24 text-xl",
  }[size] || "w-12 h-12 text-sm";

  return (
    <div
      className={`rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center overflow-hidden ${sizeClass}`}
    >
      {safeUrl ? (
        <img
          src={safeUrl}
          alt={name || "avatar"}
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
      ) : (
        <span className="text-slate-600 font-semibold select-none">
          {initials}
        </span>
      )}
    </div>
  );
}
