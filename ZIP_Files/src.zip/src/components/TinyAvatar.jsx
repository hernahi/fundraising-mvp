// src/components/TinyAvatar.jsx
import SafeAvatar from "./SafeAvatar";

export default function TinyAvatar({ name, imgUrl }) {
  return <SafeAvatar name={name} imgUrl={imgUrl} size={28} />;
}
