// src/components/SafeAvatar.jsx
import React from "react";

/**
 * SafeAvatar
 * ----------
 * - Centralized component for ALL avatars
 * - Ignores blob: URLs (caused by local object URLs)
 * - Falls back to initials when there is no valid imgUrl
 *
 * Props:
 *  - name?: string
 *  - imgUrl?: string
 *  - size?: number (px)
 *  - className?: string
 */
export default function SafeAvatar({
  name = "",
  imgUrl,
  size = 40,
  className = "",
}) {
  // Strip out invalid / transient blob: URLs
  const safeUrl =
    typeof imgUrl === "string" && imgUrl.trim() !== "" && !imgUrl.startsWith("blob:")
      ? imgUrl
      : null;

  const initials = getInitials(name);

  const baseClasses =
    "inline-flex items-center justify-center rounded-full bg-slate-200 text-slate-700 font-semibold overflow-hidden border border-slate-300";

  const style = {
    width: size,
    height: size,
    fontSize: Math.max(10, Math.floor(size / 2.4)),
  };

  if (safeUrl) {
    return (
      <div
        className={`${baseClasses} ${className}`}
        style={style}
        aria-label={name || "avatar"}
      >
        <img
          src={safeUrl}
          alt={name || "avatar"}
          className="w-full h-full object-cover"
        />
      </div>
    );
  }

  // Fallback: initials
  return (
    <div
      className={`${baseClasses} ${className}`}
      style={style}
      aria-label={name || "avatar"}
    >
      {initials || "?"}
    </div>
  );
}

function getInitials(name) {
  if (!name || typeof name !== "string") return "";

  const parts = name
    .trim()
    .split(/\s+/)
    .filter(Boolean);

  if (parts.length === 0) return "";

  if (parts.length === 1) {
    return parts[0].charAt(0).toUpperCase();
  }

  return (
    parts[0].charAt(0).toUpperCase() + parts[1].charAt(0).toUpperCase()
  );
}
