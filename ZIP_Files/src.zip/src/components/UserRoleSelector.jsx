export default function UserRoleSelector({ value, onChange }) {
  return (
    <select
      value={value}
      onChange={e => onChange(e.target.value)}
      className="border rounded p-1 text-sm"
    >
      <option value="admin">Admin</option>
      <option value="coach">Coach</option>
      <option value="athlete">Athlete</option>
      <option value="parent">Parent</option>
      <option value="donor">Donor</option>
    </select>
  );
}
