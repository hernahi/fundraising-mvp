// src/App.jsx
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import { CampaignProvider } from "./context/CampaignContext";
import { ToastProvider } from "./components/Toast";

import ProtectedRoute from "./routes/ProtectedRoute";
import RoleRoute from "./routes/RoleRoute";

// Layout
import Sidebar from "./components/Sidebar";
import Topbar from "./components/Topbar";
import DevToolsPanel from "./components/DevToolsPanel";

// Pages
import DashboardHome from "./pages/DashboardHome";
import Campaigns from "./pages/Campaigns";
import CampaignDetail from "./pages/CampaignDetail";

import Athletes from "./pages/Athletes";
import AthleteDetail from "./pages/AthleteDetail";
import AddAthlete from "./pages/AddAthlete";

import Donors from "./pages/Donors";
import AddDonor from "./pages/AddDonor";

import Coaches from "./pages/Coaches";
import AddCoach from "./pages/AddCoach";
import CoachDetail from "./pages/CoachDetail";

import Teams from "./pages/Teams";
import TeamDetail from "./pages/TeamDetail";
import AddTeam from "./pages/AddTeam";
import EditTeam from "./pages/EditTeam";

import Messages from "./pages/Messages";
import Settings from "./pages/Settings";

import PublicCampaign from "./pages/PublicCampaign";
import PublicAthlete from "./pages/PublicAthlete";
import PublicDonate from "./pages/PublicDonate";

import Login from "./pages/Login";
import AddCampaign from "./pages/AddCampaign";

import AdminUsers from "./pages/AdminUsers";
import AdminInviteUser from "./pages/AdminInviteUser";

export default function App() {
  return (
    <BrowserRouter>
      <ToastProvider>
        <AuthProvider>
          <CampaignProvider>
            <div className="min-h-screen bg-gray-50 flex">
              <Sidebar />
              <div className="flex-1 flex flex-col ml-64">
                {/* ml-64 keeps content from sitting under sidebar */}
                <Topbar />
                <main className="flex-1 p-4 sm:p-6 bg-slate-50">
                  <Routes>
                    {/* LOGIN */}
                    <Route path="/login" element={<Login />} />

                    {/* DASHBOARD */}
                    <Route
                      path="/"
                      element={
                        <ProtectedRoute>
                          <DashboardHome />
                        </ProtectedRoute>
                      }
                    />

                    {/* CAMPAIGNS */}
                    <Route
                      path="/campaigns"
                      element={
                        <ProtectedRoute>
                          <Campaigns />
                        </ProtectedRoute>
                      }
                    />
                    <Route
                      path="/campaigns/new"
                      element={
                        <ProtectedRoute>
                          <AddCampaign />
                        </ProtectedRoute>
                      }
                    />
                    <Route
                      path="/campaigns/:id"
                      element={
                        <ProtectedRoute>
                          <CampaignDetail />
                        </ProtectedRoute>
                      }
                    />

                    {/* ATHLETES */}
                    <Route
                      path="/athletes"
                      element={
                        <ProtectedRoute>
                          <Athletes />
                        </ProtectedRoute>
                      }
                    />
                    <Route
                      path="/athletes/new"
                      element={
                        <ProtectedRoute>
                          <AddAthlete />
                        </ProtectedRoute>
                      }
                    />
                    <Route
                      path="/athletes/:id"
                      element={
                        <ProtectedRoute>
                          <AthleteDetail />
                        </ProtectedRoute>
                      }
                    />

                    {/* DONORS */}
                    <Route
                      path="/donors"
                      element={
                        <ProtectedRoute>
                          <Donors />
                        </ProtectedRoute>
                      }
                    />
                    <Route
                      path="/donors/new"
                      element={
                        <ProtectedRoute>
                          <AddDonor />
                        </ProtectedRoute>
                      }
                    />

                    {/* COACHES */}
                    <Route
                      path="/coaches"
                      element={
                        <ProtectedRoute>
                          <Coaches />
                        </ProtectedRoute>
                      }
                    />
                    <Route
                      path="/coaches/new"
                      element={
                        <ProtectedRoute>
                          <AddCoach />
                        </ProtectedRoute>
                      }
                    />
                    <Route
                      path="/coaches/:id"
                      element={
                        <ProtectedRoute>
                          <CoachDetail />
                        </ProtectedRoute>
                      }
                    />

                    {/* TEAMS */}
<Route
  path="/teams"
  element={
    <ProtectedRoute>
      <Teams />
    </ProtectedRoute>
  }
/>

<Route
  path="/teams/new"
  element={
    <ProtectedRoute>
      <AddTeam />
    </ProtectedRoute>
  }
/>

<Route
  path="/teams/:id"
  element={
    <ProtectedRoute>
      <TeamDetail />
    </ProtectedRoute>
  }
/>

                    <Route
                      path="/teams/:id/edit"
                      element={
                        <ProtectedRoute>
                          <EditTeam />
                        </ProtectedRoute>
                      }
                    />
                    
                    {/* PUBLIC DONATION PAGE */}
                    <Route
                      path="/donate/:campaignId"
                      element={<PublicDonate />
                      }
                    />

                    {/* MESSAGES */}
                    <Route
                      path="/messages"
                      element={
                        <ProtectedRoute>
                          <Messages />
                        </ProtectedRoute>
                      }
                    />

                    {/* SETTINGS */}
                    <Route
                      path="/settings"
                      element={
                        <ProtectedRoute>
                          <Settings />
                        </ProtectedRoute>
                      }
                    />

                    {/* PUBLIC FUNNELS */}
                    <Route path="/c/:campaignId" element={<PublicCampaign />} />
                    <Route path="/a/:athleteId" element={<PublicAthlete />} />

                    {/* ADMIN ROUTES */}
                    <Route
                      path="/admin/users"
                      element={
                        <RoleRoute allowed={["admin"]}>
                          <AdminUsers />
                        </RoleRoute>
                      }
                    />
                    <Route
                      path="/admin/invite"
                      element={
                        <RoleRoute allowed={["admin"]}>
                          <AdminInviteUser />
                        </RoleRoute>
                      }
                    />

                    {/* 404 */}
                    <Route path="*" element={<Navigate to="/" replace />} />
                  </Routes>
                </main>
              </div>
            </div>

            <DevToolsPanel />
          </CampaignProvider>
        </AuthProvider>
      </ToastProvider>
    </BrowserRouter>
  );
}
