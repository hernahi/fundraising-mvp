// src/context/CampaignContext.jsx
import { createContext, useContext, useEffect, useState } from "react";
import { db } from "../firebase/config";
import { useAuth } from "./AuthContext";
import {
  collection,
  onSnapshot
} from "firebase/firestore";

const CampaignContext = createContext();
export const useCampaigns = () => useContext(CampaignContext);

export function CampaignProvider({ children }) {
  const { user } = useAuth();

  const [campaigns, setCampaigns] = useState([]);
  const [athletes, setAthletes] = useState([]);
  const [donations, setDonations] = useState([]);

  useEffect(() => {
    if (!user) return;
    const unsub = onSnapshot(collection(db, "campaigns"), snap => {
      setCampaigns(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    });
    return unsub;
  }, [user]);

  useEffect(() => {
    if (!user) return;
    const unsub = onSnapshot(collection(db, "athletes"), snap => {
      setAthletes(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    });
    return unsub;
  }, [user]);

  useEffect(() => {
    if (!user) return;
    const unsub = onSnapshot(collection(db, "donations"), snap => {
      setDonations(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    });
    return unsub;
  }, [user]);

  return (
    <CampaignContext.Provider value={{ campaigns, athletes, donations }}>
      {children}
    </CampaignContext.Provider>
  );
}
