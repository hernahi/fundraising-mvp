import { createContext, useContext, useEffect, useState } from "react";
import { onAuthStateChanged } from "firebase/auth";
import { auth, db } from "../firebase/config";
import { doc, getDoc, setDoc } from "firebase/firestore";

const AuthContext = createContext();
export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  // 🔥 NEW: Public routes that must NOT trigger Firestore reads
  const isPublicRoute = () => {
    const path = window.location.pathname;
    return (
      path.startsWith("/donate") ||
      path.startsWith("/public") ||
      path.includes("/donate/") ||
      path.includes("/public/")
    );
  };

  // 🔥 helper to safely create profile if needed
  async function ensureProfile(uid, email) {
    const ref = doc(db, "users", uid);
    const snap = await getDoc(ref);

    // If profile exists → load it
    if (snap.exists()) return snap.data();

    // Otherwise create default profile
    const newProfile = {
      email,
      role: "athlete",
      orgId: null,
      createdAt: Date.now()
    };

    await setDoc(ref, newProfile);
    return newProfile;
  }

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (firebaseUser) => {
      try {
        if (!firebaseUser) {
          // 🔥 No user signed in
          setUser(null);
          setProfile(null);
          setLoading(false);
          return;
        }

        setUser(firebaseUser);

        // 🔥 Prevent ANY Firestore access on public pages
        if (isPublicRoute()) {
          setProfile(null);
          setLoading(false);
          return;
        }

        // 🔥 SAFE: Only load profile when fully authenticated
        const loaded = await ensureProfile(firebaseUser.uid, firebaseUser.email);
        setProfile(loaded);
      } catch (err) {
        console.error("[AuthContext] Failed to load profile:", err);
        setProfile(null);
      } finally {
        setLoading(false);
      }
    });

    return () => unsub();
  }, []);

  return (
    <AuthContext.Provider value={{ user, profile, loading }}>
      {children}
    </AuthContext.Provider>
  );
}
