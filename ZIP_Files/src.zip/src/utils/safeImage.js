// src/utils/safeImage.js

/**
 * Sanitizes untrusted image URLs.
 * Returns "" (empty string) if unsafe.
 */
function safeImageURL(url) {
  if (!url || typeof url !== "string") {
    console.warn("🚫 Rejected unsafe image URL:", url);
    return "";
  }

  // Block javascript: and data: injections
  const lower = url.toLowerCase();
  if (lower.startsWith("javascript:") || lower.startsWith("data:")) {
    console.warn("🚫 Rejected unsafe image URL:", url);
    return "";
  }

  // OK — allow http, https, firebase storage, Cloudflare, S3, etc.
  return url;
}

// ✅ FIX — default export
export default safeImageURL;
