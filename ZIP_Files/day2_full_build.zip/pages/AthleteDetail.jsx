// Updated AthleteDetail placeholder
