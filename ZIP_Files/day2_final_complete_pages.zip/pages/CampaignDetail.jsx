import { useEffect, useState } from "react";
import { doc, getDoc } from "firebase/firestore";
import { db } from "../firebase/config";
import AvatarCore from "../components/AvatarCore";
import safeImageURL from "../utils/safeImage";

export default function CampaignDetail({ campaignId }) {
  const [campaign, setCampaign] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!campaignId) return;

    const load = async () => {
      try {
        const snap = await getDoc(doc(db, "campaigns", campaignId));
        if (!snap.exists()) {
          setError("Campaign not found");
          return;
        }
        setCampaign({ id: snap.id, ...snap.data() });
      } catch (err) {
        console.error("❌ CampaignDetail error:", err);
        setError("Unable to load campaign");
      }
    };

    load();
  }, [campaignId]);

  if (error) return <p>{error}</p>;
  if (!campaign) return <p>Loading…</p>;

  const cover = safeImageURL(campaign.coverImage);

  return (
    <div className="page-container">
      {cover && (
        <img src={cover} className="w-full max-h-64 object-cover rounded-xl mb-6" />
      )}

      <h1 className="text-3xl font-semibold mb-4">{campaign.title}</h1>

      <h2 className="font-semibold mb-2">Coaches</h2>
      <div className="flex gap-4 mb-6">
        {(campaign.coaches || []).map((c) => (
          <AvatarCore key={c.id} name={c.name} src={c.photoURL || c.imgUrl} size={48} />
        ))}
      </div>

      <h2 className="font-semibold mb-2">Athletes</h2>
      <div className="flex flex-wrap gap-4">
        {(campaign.athletes || []).map((a) => (
          <AvatarCore key={a.id} name={a.name} src={a.photoURL || a.imgUrl} size={40} />
        ))}
      </div>
    </div>
  );
}