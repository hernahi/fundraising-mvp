import { useEffect, useState } from "react";
import { collection, query, orderBy, onSnapshot } from "firebase/firestore";
import { db } from "../firebase/config";
import AvatarCore from "../components/AvatarCore";

export default function Donors() {
  const [donors, setDonors] = useState([]);

  useEffect(() => {
    const q = query(collection(db, "donors"), orderBy("createdAt", "desc"));

    const unsub = onSnapshot(q, (snap) => {
      setDonors(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
    });

    return () => unsub();
  }, []);

  return (
    <div className="page-container">
      <h1 className="page-title">Donors</h1>

      <table className="table">
        <thead>
          <tr>
            <th>Donor</th>
            <th>Email</th>
            <th>Amount</th>
            <th>Campaign</th>
            <th>Date</th>
          </tr>
        </thead>

        <tbody>
          {donors.map((d) => {
            const img = d.photoURL || d.photoUrl || d.imgUrl;

            return (
              <tr key={d.id}>
                <td className="flex items-center gap-2">
                  <AvatarCore name={d.name} src={img} size={32} />
                  {d.name}
                </td>
                <td>{d.email}</td>
                <td>${d.amount}</td>
                <td>{d.campaignName}</td>
                <td>
                  {d.createdAt?.toDate?.().toLocaleDateString?.() || "---"}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}