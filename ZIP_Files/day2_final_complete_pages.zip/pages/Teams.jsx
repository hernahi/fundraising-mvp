import { useEffect, useState } from "react";
import { collection, onSnapshot } from "firebase/firestore";
import { db } from "../firebase/config";
import safeImageURL from "../utils/safeImage";

export default function Teams() {
  const [teams, setTeams] = useState([]);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, "teams"), (snap) => {
      setTeams(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
    });

    return () => unsub();
  }, []);

  return (
    <div className="page-container">
      <h1 className="page-title">Teams</h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {teams.map((team) => (
          <div key={team.id} className="team-card bg-white p-4 rounded-xl shadow flex flex-col items-center">
            <img className="team-logo w-20 h-20 object-cover rounded-full"
                 src={safeImageURL(team.logoURL)}
                 alt={team.name} />
            <h2 className="mt-3 font-semibold">{team.name}</h2>
            <p className="text-slate-500 text-sm">{team.sport} — {team.level}</p>
          </div>
        ))}
      </div>
    </div>
  );
}