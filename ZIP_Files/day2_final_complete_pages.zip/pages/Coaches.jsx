import { useEffect, useState } from "react";
import { collection, onSnapshot } from "firebase/firestore";
import { db } from "../firebase/config";
import AvatarCore from "../components/AvatarCore";

export default function Coaches() {
  const [coaches, setCoaches] = useState([]);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, "coaches"), (snap) => {
      setCoaches(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
    });

    return () => unsub();
  }, []);

  return (
    <div className="page-container">
      <h1 className="page-title">Coaches</h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {coaches.map((coach) => (
          <div key={coach.id} className="p-4 bg-white rounded-xl shadow flex flex-col items-center">
            <AvatarCore name={coach.name} src={coach.photoURL || coach.imgUrl} size={64} />
            <h2 className="mt-3 font-semibold">{coach.name}</h2>
            <p className="text-slate-500 text-sm">{coach.email}</p>
            {coach.teamName && (
              <p className="text-slate-400 text-sm">{coach.teamName}</p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}