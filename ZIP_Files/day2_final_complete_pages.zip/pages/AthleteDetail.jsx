import { useEffect, useState } from "react";
import { doc, getDoc } from "firebase/firestore";
import { db } from "../firebase/config";
import AvatarCore from "../components/AvatarCore";
import safeImageURL from "../utils/safeImage";

export default function AthleteDetail({ athleteId }) {
  const [athlete, setAthlete] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!athleteId) return;

    const load = async () => {
      try {
        const ref = doc(db, "athletes", athleteId);
        const snap = await getDoc(ref);

        if (!snap.exists()) {
          setError("Athlete not found");
          return;
        }

        setAthlete({ id: snap.id, ...snap.data() });
      } catch (err) {
        console.error("❌ AthleteDetail error:", err);
        setError("Unable to load athlete.");
      }
    };

    load();
  }, [athleteId]);

  if (error) return <p className="error">{error}</p>;
  if (!athlete) return <p>Loading athlete…</p>;

  const img = athlete.photoURL || athlete.photoUrl || athlete.imgUrl || null;

  return (
    <div className="page-container">
      <div className="flex items-center gap-4 mb-6">
        <AvatarCore name={athlete.name} src={img} size={64} />
        <div>
          <h1 className="text-2xl font-semibold">{athlete.name}</h1>
          {athlete.jerseyNumber && (
            <p className="text-slate-500">#{athlete.jerseyNumber}</p>
          )}
        </div>
      </div>

      {athlete.bio && (
        <div className="bg-white p-4 rounded-lg shadow">
          <h2 className="font-semibold mb-2">Bio</h2>
          <p>{athlete.bio}</p>
        </div>
      )}
    </div>
  );
}