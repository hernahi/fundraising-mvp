import { useEffect, useState } from "react";
import { collection, onSnapshot, query, where } from "firebase/firestore";
import { db } from "../firebase/config";
import AvatarCore from "../components/AvatarCore";

export default function Athletes({ user }) {
  const [athletes, setAthletes] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!user?.teamId) return;

    const q = query(collection(db, "athletes"), where("teamId", "==", user.teamId));

    const unsub = onSnapshot(
      q,
      (snap) => {
        const list = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
        setAthletes(list);
      },
      (err) => {
        console.error("❌ Athletes listener error:", err);
        setError("Unable to load athletes");
      }
    );

    return () => unsub();
  }, [user?.teamId]);

  return (
    <div className="page-container">
      <h1 className="page-title">Athletes</h1>
      {error && <p className="error">{error}</p>}

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {athletes.map((a) => {
          const img = a.photoURL || a.photoUrl || a.imgUrl;

          return (
            <div key={a.id} className="bg-white p-4 rounded-xl shadow flex flex-col items-center">
              <AvatarCore name={a.name} src={img} size={64} />
              <h3 className="font-semibold mt-3">{a.name}</h3>
              {a.jerseyNumber && (
                <p className="text-slate-500 text-sm">Jersey #{a.jerseyNumber}</p>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}